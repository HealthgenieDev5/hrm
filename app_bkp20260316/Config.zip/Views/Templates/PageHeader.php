<!-- begin::Header-->
<div id="kt_header" class="header align-items-stretch">
	<!--begin::Container-->
	<div class="container-fluid d-flex align-items-stretch justify-content-between">
		<!--begin::Aside mobile toggle-->
		<div class="d-flex align-items-center d-lg-none ms-n2 me-2" title="Show aside menu">
			<div class="btn btn-icon btn-active-light-primary w-30px h-30px w-md-40px h-md-40px" id="kt_aside_mobile_toggle">
				<!--begin::Svg Icon | path: icons/duotune/abstract/abs015.svg-->
				<span class="svg-icon svg-icon-1">
					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
						<path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black" />
						<path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black" />
					</svg>
				</span>
				<!--end::Svg Icon-->
			</div>
		</div>
		<!--end::Aside mobile toggle-->
		<!--begin::Mobile logo-->
		<div class="d-flex align-items-center flex-grow-1 flex-lg-grow-0">
			<a href="<?php echo base_url(); ?>" class="d-lg-none">
				<!-- <img alt="Logo" src="<?php #echo base_url(); 
											?>/assets/media/logos/logo-2.svg" class="h-30px" /> -->
				<img alt="Logo" src="<?php echo base_url(); ?>assets/media/logos/logo-healthgenie.png" class="h-30px logo" />
			</a>
		</div>
		<!--end::Mobile logo-->
		<!--begin::Wrapper-->
		<div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1">
			<h4 class="mb-0 d-none d-lg-flex align-items-center"><?= $page_title ?></h4>
			<!--begin::Toolbar wrapper-->
			<div class="d-flex align-items-stretch flex-shrink-0">



				<!-- <div class="d-flex align-items-center ms-1 ms-lg-3 me-3" id="kt_header_notification_toggle">
					<div class="cursor-pointer symbol symbol-30px symbol-md-40px" data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
						<i class="fa fa-bell"></i>
					</div>
					<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px" data-kt-menu="true">
						<div class="menu-item px-5">
							My Profile
						</div>
						<div class="separator my-2"></div>
						<div class="menu-item px-5" id="">
							CRM System Development
						</div>
						<div class="separator my-2"></div>
					</div>
				</div> -->

				<!--begin::User menu-->
				<div class="d-flex align-items-center ms-1 ms-lg-3" id="kt_header_user_menu_toggle">
					<!--begin::Menu wrapper-->
					<div class="cursor-pointer symbol symbol-30px symbol-md-40px" data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
						<?php
						$avatar_url = '';
						$attachment_json = session()->get('current_user')['attachment'];
						if (!empty($attachment_json)) {
							$attachment = json_decode($attachment_json, true);
							if (isset($attachment['avatar']['file']) && !empty($attachment['avatar']['file'])) {
								$avatar_url = $attachment['avatar']['file'];
							}
						}
						if (!empty($avatar_url)) {
						?><img src="<?php echo base_url() . $avatar_url; ?>" alt="user" /><?php
																								} else {
																									?>
							<p class="mb-0 text-center rounded bg-info bg-opacity-20 text-primary" style="width: 40px; height: 40px; line-height: 40px;">
								<?= substr(session()->get('current_user')['name'], 0, 1) ?>
							</p>
						<?php
																								}
						?>
					</div>
					<!--begin::User account menu-->
					<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px" data-kt-menu="true">
						<!--begin::Menu item-->
						<div class="menu-item px-3">
							<div class="menu-content d-flex align-items-center px-3">
								<!--begin::Avatar-->
								<div class="symbol symbol-50px me-5">
									<?php
									$avatar_url = '';
									$attachment_json = session()->get('current_user')['attachment'];
									if (!empty($attachment_json)) {
										$attachment = json_decode($attachment_json, true);
										if (isset($attachment['avatar']['file']) && !empty($attachment['avatar']['file'])) {
											$avatar_url = $attachment['avatar']['file'];
										}
									}
									if (!empty($avatar_url)) {
									?><img src="<?php echo base_url() . $avatar_url; ?>" alt="user" /><?php
																											} else {
																												?>
										<p class="mb-0 text-center rounded bg-info bg-opacity-20 text-primary" style="width:50px; height:50px; line-height: 50px;">
											<?= substr(session()->get('current_user')['name'], 0, 1) ?>
										</p>
									<?php
																											}
									?>
								</div>
								<!--end::Avatar-->
								<!--begin::Username-->
								<div class="d-flex flex-column">
									<div class="fw-bolder d-flex flex-column align-items-baseline fs-5">
										<span><?= session()->get('current_user')['name'] ?></span><br>
										<span class="badge badge-light-success fw-bolder fs-8 px-2 py-1 ms-0"><?= session()->get('current_user')['role'] ?></span>
									</div>
									<a href="#" class="fw-bold text-muted text-hover-primary fs-7"><?= session()->get('current_user')['work_email'] ?></a>
								</div>
								<!--end::Username-->
							</div>
						</div>
						<!--end::Menu item-->
						<!--begin::Menu separator-->
						<div class="separator my-2"></div>
						<!--end::Menu separator-->
						<!--begin::Menu item-->
						<div class="menu-item px-5">
							<a href="<?php echo base_url(); ?>" class="menu-link px-5">My Profile</a>
						</div>
						<!--end::Menu item-->
						<!--begin::Menu item-->
						<?php if (session()->get('current_user')['employee_id'] == '40') { ?>
							<div class="menu-item px-5">
								<a href="<?php echo base_url('/profile/edit'); ?>" class="menu-link px-5">Edit Your Profile</a>
							</div>
						<?php } ?>
						<!--end::Menu item-->
						<!--begin::Menu separator-->
						<div class="separator my-2"></div>
						<!--end::Menu separator-->
						<!--begin::Menu item-->
						<div class="menu-item px-5">
							<a href="<?php echo base_url('logout'); ?>" class="menu-link px-5">Logout</a>
						</div>
						<!--end::Menu item-->
					</div>
					<!--end::User account menu-->
					<!--end::Menu wrapper-->
				</div>
				<!--end::User menu-->
			</div>
			<!--end::Toolbar wrapper-->
		</div>
		<!--end::Wrapper-->
	</div>
	<!--end::Container-->
</div>
<!--end::Header
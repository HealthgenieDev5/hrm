<?= $this->extend('Templates/DashboardLayout') ?>

<?= $this->section('content') ?>



<div class="row gy-5 g-xl-8">
    <div class="col-lg-6 col-xxl-8 order-2 order-lg-1">

        <div class="card shadow-sm mb-5">
            <div class="card-body">
                <div class="row d-flex flex-wrap gy-3 g-x-3">
                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">
                        <div class="d-flex align-items-center">
                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if ($seven_days_late_minutes_avg <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif ($seven_days_late_minutes_avg > 10 && $seven_days_late_minutes_avg <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>
                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $seven_days_late_minutes_avg; ?>" data-kt-countup-suffix=" Minutes">0</div>
                        </div>
                        <div class="fw-bold fs-9 text-gray-600">Avg Late in last 7 days</div>
                    </div>
                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">

                        <div class="d-flex align-items-center">

                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if ($fifteen_days_late_minutes_avg <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif ($fifteen_days_late_minutes_avg > 10 && $fifteen_days_late_minutes_avg <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>

                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $fifteen_days_late_minutes_avg; ?>" data-kt-countup-suffix=" Minutes">0</div>
                        </div>


                        <div class="fw-bold fs-9 text-gray-600">Avg Late in last 15 days</div>

                    </div>



                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">

                        <div class="d-flex align-items-center">

                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if ($current_month_late_minutes_avg <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif ($current_month_late_minutes_avg > 10 && $current_month_late_minutes_avg <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>

                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $current_month_late_minutes_avg; ?>" data-kt-countup-suffix=" Minutes">0</div>
                        </div>


                        <div class="fw-bold fs-9 text-gray-600">Avg Late in Current Month</div>

                    </div>



                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">

                        <div class="d-flex align-items-center">

                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if (round($current_month_late_minutes / date('d')) <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif (round($current_month_late_minutes / date('d')) > 10 && round($current_month_late_minutes / date('d')) <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>

                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $current_month_late_minutes; ?>" data-kt-countup-suffix=" Minutes">0</div>
                        </div>


                        <div class="fw-bold fs-9 text-gray-600">Total Late in Current Month</div>

                    </div>



                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">

                        <div class="d-flex align-items-center">

                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if ($seven_days_early_going_minutes_avg <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif ($seven_days_early_going_minutes_avg > 10 && $seven_days_early_going_minutes_avg <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>

                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $seven_days_early_going_minutes_avg; ?>" data-kt-countup-suffix=" Minutes">0</div>
                        </div>


                        <div class="fw-bold fs-9 text-gray-600">Avg Early Going in last 7 days</div>

                    </div>



                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">

                        <div class="d-flex align-items-center">

                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if ($fifteen_days_early_going_minutes_avg <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif ($fifteen_days_early_going_minutes_avg > 10 && $fifteen_days_early_going_minutes_avg <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>

                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $fifteen_days_early_going_minutes_avg; ?>" data-kt-countup-suffix=" Minutes">0</div>
                        </div>


                        <div class="fw-bold fs-9 text-gray-600">Avg Early Going in last 15 days</div>

                    </div>



                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">

                        <div class="d-flex align-items-center">

                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if ($current_month_early_going_minutes_avg <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif ($current_month_early_going_minutes_avg > 10 && $current_month_early_going_minutes_avg <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>

                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $current_month_early_going_minutes_avg; ?>" data-kt-countup-suffix=" Minutes">0</div>
                        </div>


                        <div class="fw-bold fs-9 text-gray-600">Avg Early Going in Current Month</div>

                    </div>



                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">

                        <div class="d-flex align-items-center">

                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if (round($current_month_early_going_minutes / date('d')) <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif (round($current_month_early_going_minutes / date('d')) > 10 && round($current_month_early_going_minutes / date('d')) <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>

                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $current_month_early_going_minutes; ?>" data-kt-countup-suffix=" Minutes">0</div>

                        </div>


                        <div class="fw-bold fs-9 text-gray-600">Total Early Going in Current Month</div>

                    </div>



                    <div class="border border-gray-400 border-dashed rounded w-auto min-w-125px py-3 px-4 me-3">

                        <div class="d-flex align-items-center">

                            <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                                <?php
                                if (round($current_date_early_going_minutes / date('d')) <= 10) {
                                ?>
                                    <i class="fa-solid fa-arrow-down text-success me-2"></i>
                                <?php
                                } elseif (round($current_date_early_going_minutes / date('d')) > 10 && round($current_date_early_going_minutes / date('d')) <= 20) {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-warning me-2"></i>
                                <?php
                                } else {
                                ?>
                                    <i class="fa-solid fa-arrow-up text-danger me-2"></i>
                                <?php
                                }
                                ?>
                            </span>

                            <div class="fs-5 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?php echo $current_date_early_going_minutes; ?>" data-kt-countup-suffix=" Minutes">0</div>
                        </div>


                        <div class="fw-bold fs-9 text-gray-600">Total Early Going Today</div>

                    </div>

                </div>
            </div>
        </div>

        <div class="mb-5">
            <style>
                .dataTables_scrollBody {
                    max-height: 400px;
                }
            </style>
            <table id="punching_report_table" class="table table-row-bordered table-striped nowrap">
                <thead>
                    <tr>
                        <th class="text-center"><strong>Date</strong></th>
                        <th class="text-center"><strong>Day</strong></th>
                        <th class="text-center"><strong>Status</strong></th>
                        <th class="text-center"><strong>Shift</strong></th>
                        <th class="text-center"><strong>IN/OUT</strong></th>
                        <th class="text-center"><strong>Late IN</strong></th>
                        <th class="text-center"><strong>Early Out</strong></th>
                        <th class="text-center"><strong>Late+Early</strong></th>
                        <th class="text-center"><strong>Work+OD</strong><br><small>Within Shift</small></th>
                        <th class="text-center"><strong>paid</strong></th>
                        <th class="text-center"><strong>Grace</strong></th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th class="text-center"><strong>Date</strong></th>
                        <th class="text-center"><strong>Day</strong></th>
                        <th class="text-center"><strong>Status</strong></th>
                        <th class="text-center"><strong>Shift</strong></th>
                        <th class="text-center"><strong>IN/OUT</strong></th>
                        <th class="text-center"><strong>Late IN</strong></th>
                        <th class="text-center"><strong>Early Out</strong></th>
                        <th class="text-center"><strong>Late+Early</strong></th>
                        <th class="text-center"><strong>Work+OD</strong><br><small>Within Shift</small></th>
                        <th class="text-center"><strong>paid</strong></th>
                        <th class="text-center"><strong>Grace</strong></th>
                    </tr>
                </tfoot>
                <tbody>
                </tbody>
            </table>
        </div>

        <div class="mb-5">
            <style>
                .dataTables_scrollBody {
                    max-height: 400px;
                }
            </style>
            <table id="leave_report_table" class="table table-striped table-row-bordered nowrap">
                <thead>
                    <tr>
                        <th class="text-center"><strong>Leave Date</strong></th>
                        <th class="text-center"><strong>Days</strong></th>
                        <th class="text-center"><strong>Day Type</strong></th>
                        <th class="text-center"><strong>Leave Code</strong></th>
                        <th class="text-center"><strong>Status</strong></th>
                        <th class="text-center"><strong>Reviewed By</strong></th>
                        <th class="text-center"><strong>Reviewed Date</strong></th>
                        <th class="text-center"><strong>Remarks</strong></th>
                        <th class="text-center"><strong>Address During Leave</strong></th>
                        <th class="text-center"><strong>Contact During Leave</strong></th>
                        <th class="text-center"><strong>Reason</strong></th>
                        <th class="text-center"><strong>Attachment</strong></th>
                        <th class="text-center"><strong>Requested Date Time</strong></th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th class="text-center"><strong>Leave Date</strong></th>
                        <th class="text-center"><strong>Days</strong></th>
                        <th class="text-center"><strong>Day Type</strong></th>
                        <th class="text-center"><strong>Leave Code</strong></th>
                        <th class="text-center"><strong>Status</strong></th>
                        <th class="text-center"><strong>Reviewed By</strong></th>
                        <th class="text-center"><strong>Reviewed Date</strong></th>
                        <th class="text-center"><strong>Remarks</strong></th>
                        <th class="text-center"><strong>Address During Leave</strong></th>
                        <th class="text-center"><strong>Contact During Leave</strong></th>
                        <th class="text-center"><strong>Reason</strong></th>
                        <th class="text-center"><strong>Attachment</strong></th>
                        <th class="text-center"><strong>Requested Date Time</strong></th>
                    </tr>
                </tfoot>
                <tbody>
                </tbody>
            </table>
        </div>

        <div class="row mb-5">
            <style>
                .dataTables_scrollBody {
                    max-height: 400px;
                }
            </style>
            <div class="col-md-6">
                <table id="od_report_table_approved" class="table table-striped table-row-bordered nowrap">
                    <thead>
                        <tr>
                            <th class="text-center"><strong>Pre/Post</strong></th>
                            <th class="text-center"><strong>Estimated From</strong></th>
                            <th class="text-center"><strong>Estimated To</strong></th>
                            <th class="text-center"><strong>Actual From</strong></th>
                            <th class="text-center"><strong>Actual To</strong></th>
                            <th class="text-center"><strong>Hours</strong></th>
                            <th class="text-center"><strong>Duty Location</strong></th>
                            <th class="text-center"><strong>Assigned By</strong></th>
                            <th class="text-center"><strong>Reason</strong></th>
                            <th class="text-center"><strong>Status</strong></th>
                            <th class="text-center"><strong>Reviewed By</strong></th>
                            <th class="text-center"><strong>Reviewed Date Time</strong></th>
                            <th class="text-center"><strong>Remarks</strong></th>
                            <th class="text-center"><strong>Updated Date Time</strong></th>
                            <th class="text-center"><strong>Requested Date Time</strong></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th class="text-center"><strong>Pre/Post</strong></th>
                            <th class="text-center"><strong>Estimated From</strong></th>
                            <th class="text-center"><strong>Estimated To</strong></th>
                            <th class="text-center"><strong>Actual From</strong></th>
                            <th class="text-center"><strong>Actual To</strong></th>
                            <th class="text-center"><strong>Hours</strong></th>
                            <th class="text-center"><strong>Duty Location</strong></th>
                            <th class="text-center"><strong>Assigned By</strong></th>
                            <th class="text-center"><strong>Reason</strong></th>
                            <th class="text-center"><strong>Status</strong></th>
                            <th class="text-center"><strong>Reviewed By</strong></th>
                            <th class="text-center"><strong>Reviewed Date Time</strong></th>
                            <th class="text-center"><strong>Remarks</strong></th>
                            <th class="text-center"><strong>Updated Date Time</strong></th>
                            <th class="text-center"><strong>Requested Date Time</strong></th>
                        </tr>
                    </tfoot>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6">
                <table id="od_report_table_pending" class="table table-striped table-row-bordered nowrap">
                    <thead>
                        <tr>
                            <th class="text-center"><strong>Pre/Post</strong></th>
                            <th class="text-center"><strong>Estimated From</strong></th>
                            <th class="text-center"><strong>Estimated To</strong></th>
                            <th class="text-center"><strong>Actual From</strong></th>
                            <th class="text-center"><strong>Actual To</strong></th>
                            <th class="text-center"><strong>Hours</strong></th>
                            <th class="text-center"><strong>Duty Location</strong></th>
                            <th class="text-center"><strong>Assigned By</strong></th>
                            <th class="text-center"><strong>Reason</strong></th>
                            <th class="text-center"><strong>Status</strong></th>
                            <th class="text-center"><strong>Reviewed By</strong></th>
                            <th class="text-center"><strong>Reviewed Date Time</strong></th>
                            <th class="text-center"><strong>Remarks</strong></th>
                            <th class="text-center"><strong>Updated Date Time</strong></th>
                            <th class="text-center"><strong>Requested Date Time</strong></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th class="text-center"><strong>Pre/Post</strong></th>
                            <th class="text-center"><strong>Estimated From</strong></th>
                            <th class="text-center"><strong>Estimated To</strong></th>
                            <th class="text-center"><strong>Actual From</strong></th>
                            <th class="text-center"><strong>Actual To</strong></th>
                            <th class="text-center"><strong>Hours</strong></th>
                            <th class="text-center"><strong>Duty Location</strong></th>
                            <th class="text-center"><strong>Assigned By</strong></th>
                            <th class="text-center"><strong>Reason</strong></th>
                            <th class="text-center"><strong>Status</strong></th>
                            <th class="text-center"><strong>Reviewed By</strong></th>
                            <th class="text-center"><strong>Reviewed Date Time</strong></th>
                            <th class="text-center"><strong>Remarks</strong></th>
                            <th class="text-center"><strong>Updated Date Time</strong></th>
                            <th class="text-center"><strong>Requested Date Time</strong></th>
                        </tr>
                    </tfoot>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>

    </div>



    <div class="col-lg-6 col-xxl-4 order-1 order-lg-2 ">

        <div class="card shadow-sm mb-5">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div class="me-7 d-flex flex-column">
                        <div class="symbol w-100px position-relative">
                            <?php
                            $avatar_url = '';
                            $attachment_json = session()->get('current_user')['attachment'];
                            if (!empty($attachment_json)) {
                                $attachment = json_decode($attachment_json, true);
                                if (isset($attachment['avatar']['file']) && !empty($attachment['avatar']['file'])) {
                                    $avatar_url = $attachment['avatar']['file'];
                                }
                            }
                            if (!empty($avatar_url)) {
                            ?>
                                <img class="w-100 h-auto" src="<?php echo base_url() . $avatar_url; ?>" alt="user" />
                            <?php
                            } else {
                            ?>
                                <img class="w-100 h-auto" src="<?= base_url() ?>/public/assets/media/avatars/blank.png" alt="image">
                            <?php
                            }
                            ?>
                            <div class="position-absolute translate-middle bottom-0 start-100 mb-6 bg-success rounded-circle border border-4 border-white h-20px w-20px"></div>
                        </div>
                        <div class="border border-gray-400 border-dashed rounded py-3 px-4 mt-3">

                            <div class="d-flex align-items-center justify-content-between">
                                <div class="fw-bold fs-6 text-gray-600">Code</div>
                                <div class="fw-bold fs-6 text-gray-900"><?php echo $current_user_data['internal_employee_id']; ?></div>
                            </div>

                        </div>
                    </div>
                    <div class="flex-grow-1 d-flex flex-column justify-content-between">
                        <div class="d-flex align-items-center mb-2">
                            <a href="#" class="text-gray-900 text-hover-primary fs-2 fw-bolder me-1">
                                <?php echo trim($current_user_data['first_name'] . ' ' . $current_user_data['last_name']); ?>
                            </a>
                            <a href="#">
                                <span class="svg-icon svg-icon-1 svg-icon-primary">
                                    <i class="fa-solid fa-badge-check text-primary" style="font-size: 1.37rem;"></i>
                                </span>
                            </a>
                        </div>
                        <div class="d-flex flex-column fw-bold fs-6">
                            <?php
                            if (!empty($current_user_data['designation_name'])) {
                            ?>
                                <a href="#" class="d-flex align-items-center text-gray-400 text-hover-primary mb-1">
                                    <span class="svg-icon svg-icon-4 me-3">
                                        <i class="fa-duotone fa-circle-user text-hover-primary"></i>
                                    </span>
                                    <?php echo $current_user_data['designation_name']; ?>
                                </a>
                            <?php
                            }
                            if (!empty($current_user_data['department_name'])) {
                            ?>
                                <a href="#" class="d-flex align-items-center text-gray-400 text-hover-primary mb-1">
                                    <span class="svg-icon svg-icon-4 me-3">
                                        <i class="fa-solid fa-building-user text-hover-primary"></i>
                                    </span>
                                    <?php echo $current_user_data['department_name']; ?>
                                </a>
                            <?php
                            }
                            if (!empty($current_user_data['company_short_name'])) {
                            ?>
                                <a href="#" class="d-flex align-items-center text-gray-400 text-hover-primary mb-1">
                                    <span class="svg-icon svg-icon-4 me-3">
                                        <i class="fa-solid fa-house-building text-hover-primary"></i>
                                    </span>
                                    <?php echo $current_user_data['company_short_name']; ?>
                                </a>
                            <?php
                            }
                            if (!empty($current_user_data['desk_location'])) {
                            ?>
                                <a href="#" class="d-flex align-items-center text-gray-400 text-hover-primary mb-1">
                                    <span class="svg-icon svg-icon-4 me-3">
                                        <i class="fa-duotone fa-location-dot text-hover-primary"></i>
                                    </span>
                                    <?php echo $current_user_data['desk_location']; ?>
                                </a>
                            <?php
                            }
                            if (!empty($current_user_data['work_email'])) {
                            ?>
                                <a href="#" class="d-flex align-items-center text-gray-400 text-hover-primary mb-1">
                                    <span class="svg-icon svg-icon-4 me-3">
                                        <i class="fa-duotone fa-envelope text-hover-primary"></i>
                                    </span>
                                    <?php echo $current_user_data['work_email']; ?>
                                </a>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="shadow-sm mb-5">
            <table id="leave_balance_current_month" class="table table-sm table-row-bordered">
                <thead>
                    <tr>
                        <th style="text-align: left"><strong>Type</strong></th>
                        <th style="text-align: right"><strong>Balance</strong></th>
                    </tr>
                </thead>
            </table>
            <div id="_rh_dates">
                <input type="hidden" id="first_rh_date" value="" />
                <input type="hidden" id="second_rh_date" value="" />
            </div>
        </div>
        <div class="card shadow-sm mb-5">
            <div class="card-footer pb-3">
                <div class="d-flex align-items-center justify-content-between flex-wrap">
                    <button type="button" class="btn btn-sm btn-primary flex-grow-1 mb-2 mx-1" data-bs-toggle="modal" data-bs-target="#create_leave_request_modal" id="create_leave_request_button_trigger" disabled>
                        Please Wait
                    </button>

                    <button type="button" class="btn btn-sm btn-info flex-grow-1 mb-2 mx-1" data-bs-toggle="modal" data-bs-target="#create_od_request_modal">
                        <i class="fa fa-plus"></i> Request OD
                    </button>

                    <button type="button" class="btn btn-sm btn-warning text-dark flex-grow-1 mb-2 mx-1" data-bs-toggle="modal" data-bs-target="#comp_off_credit_request_modal">
                        <i class="fa fa-plus text-dark"></i> COMP OFF Credit Request
                    </button>
                    <button type="button" class="btn btn-sm btn-danger flex-grow-1 mb-2 mx-1" data-bs-toggle="modal" data-bs-target="#comp_off_minutes_utilization_request_modal" style="max-width: max-content;">
                        <i class="fa fa-plus"></i> Use Comp Off Minutes
                    </button>

                    <div class="modal fade" tabindex="-1" id="create_leave_request_modal">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content">
                                <form id="create_leave_request" method="post">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Request New Leave</h5>
                                        <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                                            <span class="svg-icon svg-icon-2x"></span>
                                        </div>
                                    </div>

                                    <div class="modal-body">
                                        <div class="row ">
                                            <div class="col-lg-3 mb-3">
                                                <label class="form-label">From Date</label>
                                                <div class="input-group">
                                                    <input type="text" id="from_date" class="leave-control form-control form-control-sm" name="from_date" placeholder="Pick a Date" value="<?= set_value('from_date') ?>" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
                                                    <span class="input-group-text input-group-solid cursor-pointer parent-picker">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <small class="text-danger error-text" id="from_date_error"><?= isset($validation) ? display_error($validation, 'from_date') : '' ?></small>
                                            </div>

                                            <div class="col-lg-3 mb-3">
                                                <label class="form-label">To Date</label>
                                                <div class="input-group">
                                                    <input type="text" id="to_date" class="leave-control form-control form-control-sm" name="to_date" placeholder="Pick a Date" value="<?= set_value('to_date') ?>" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
                                                    <span class="input-group-text input-group-solid cursor-pointer parent-picker">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <small class="text-danger error-text" id="to_date_error"><?= isset($validation) ? display_error($validation, 'to_date') : '' ?></small>
                                            </div>

                                            <div class="col-lg-3 mb-3">
                                                <label class="required form-label">Day Type</label>
                                                <div class="switch-toggle form-control form-control-sm form-control-solid d-flex p-0 position-relative">
                                                    <label for="day_type_half_day" class="text-center form-control form-control-sm bg-transparent border-0 position-relative">
                                                        Half Day <input type="radio" name="day_type" class="opacity-1  day_type" id="day_type_half_day" value="0.5" style="width: 0px; opacity: 0;" />
                                                    </label>
                                                    <label for="day_type_full_day" class="text-center form-control form-control-sm bg-transparent border-0 position-relative">
                                                        Full Day <input type="radio" name="day_type" class="opacity-1  day_type" id="day_type_full_day" value="1" style="width: 0px; opacity: 0;" checked />
                                                    </label>
                                                    <a class="bg-info form-control form-control-sm p-0 position-absolute" style="opacity: 0.5"></a>
                                                </div>
                                                <span class="text-danger error-text" id="type_of_leave_error"><?= isset($validation) ? display_error($validation, 'type_of_leave') : '' ?></span>
                                            </div>

                                            <div class="col-lg-3 mb-3">
                                                <label class="form-label">Days</label>
                                                <input type="text" class="form-control form-control-sm leave_request_number_of_days" id="number_of_days" name="number_of_days" placeholder="--" />
                                                <strong class="w-100 text-success included-rh-days"></strong>
                                                <small class="w-100 text-danger error-text" id="number_of_days_error"><?= isset($validation) ? display_error($validation, 'number_of_days') : '' ?></small>
                                            </div>

                                            <div class="col-lg-6 mb-3">
                                                <label class="required form-label">Type of leave</label>
                                                <div class="switch-toggle form-control form-control-sm form-control-solid d-flex p-0 position-relative">
                                                    <?php if ($current_user_data['el_allowed'] == 'yes') { ?>
                                                        <label for="type_of_leave_el" class="text-center form-control form-control-sm bg-transparent border-0 position-relative">
                                                            EL <input type="radio" name="type_of_leave" class="opacity-0 position-absolute type_of_leave" id="type_of_leave_el" value="EL" />
                                                        </label>
                                                    <?php } ?>
                                                    <?php if ($current_user_data['cl_allowed'] == 'yes') { ?>
                                                        <label for="type_of_leave_cl" class="text-center form-control form-control-sm bg-transparent border-0 position-relative">
                                                            CL <input type="radio" name="type_of_leave" class="opacity-0 position-absolute type_of_leave" id="type_of_leave_cl" value="CL" checked />
                                                        </label>
                                                    <?php } ?>
                                                    <?php if ($current_user_data['co_allowed'] == 'yes') { ?>
                                                        <label for="type_of_leave_comp_off" class="text-center form-control form-control-sm bg-transparent border-0 position-relative">
                                                            COMP OFF <input type="radio" name="type_of_leave" class="opacity-0 position-absolute type_of_leave" id="type_of_leave_comp_off" value="COMP OFF" />
                                                        </label>
                                                    <?php } ?>
                                                    <?php if ($current_user_data['sl_allowed'] == 'yes') { ?>
                                                        <label for="type_of_leave_sick_leave" class="text-center form-control form-control-sm bg-transparent border-0 position-relative">
                                                            SICK LEAVE <input type="radio" name="type_of_leave" class="opacity-0 position-absolute type_of_leave" id="type_of_leave_sick_leave" value="SICK LEAVE" />
                                                        </label>
                                                    <?php } ?>
                                                    <a class="bg-danger form-control form-control-sm p-0 position-absolute"></a>
                                                </div>
                                                <span class="text-danger error-text" id="type_of_leave_error">
                                                    <?= isset($validation) ? display_error($validation, 'type_of_leave') : '' ?>
                                                </span>
                                            </div>

                                            <div class="col-lg-6 mb-3">
                                                <label class="form-label">Emergency Contact During Leave</label>
                                                <input type="text" id="emergency_contact_d_l" name="emergency_contact_d_l" class="form-control form-control-sm" placeholder="Emergency Contact During Leave" value="<?= set_value('emergency_contact_d_l') ?>" />
                                                <small class="text-danger error-text" id="emergency_contact_d_l_error"><?= isset($validation) ? display_error($validation, 'emergency_contact_d_l') : '' ?></small>
                                            </div>

                                            <div class="col-lg-6 mb-3">
                                                <label class="form-label">Address During Leave</label>
                                                <input type="text" id="address_d_l" name="address_d_l" class="form-control form-control-sm" placeholder="Address During Leave" value="<?= set_value('address_d_l') ?>" />
                                                <small class="text-danger error-text" id="address_d_l_error"><?= isset($validation) ? display_error($validation, 'address_d_l') : '' ?></small>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="form-label">Reason of Leave</label>
                                                <input type="text" id="reason_of_leave" name="reason_of_leave" class="form-control form-control-sm" placeholder="Reason of Leave" value="<?= set_value('reason_of_leave') ?>" />
                                                <small class="text-danger error-text" id="reason_of_leave_error"><?= isset($validation) ? display_error($validation, 'reason_of_leave') : '' ?></small>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="form-label">Attachment</label><br>
                                                <div id="attachment_select" class="image-input image-input-outline image-input-empty" data-kt-image-input="true" style="background-image: url(<?php echo base_url(); ?>assets/media/svg/files/blank-image.svg)">
                                                    <div class="image-input-wrapper w-125px h-125px">
                                                        <a class="d-none w-100 h-100 overlay preview-button" data-bs-target="#leave_attachment_lightbox" data-bs-toggle="modal">
                                                            <div class="overlay-layer card-rounded bg-dark bg-opacity-25 shadow"><i class="bi bi-eye-fill text-white fs-3x"></i></div>
                                                        </a>
                                                    </div>
                                                    <label class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" data-bs-dismiss="click" title="Change Attachment">
                                                        <i class="bi bi-pencil-fill fs-7"></i>
                                                        <input type="file" id="attachment" name="attachment" accept=".png, .jpg, .jpeg, .pdf" />
                                                        <input type="hidden" name="attachment_remove" />
                                                    </label>
                                                    <span class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" data-bs-dismiss="click" title="Cancel Attachment">
                                                        <i class="bi bi-x fs-2"></i>
                                                    </span>
                                                    <span class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" data-bs-dismiss="click" title="Remove Attachment">
                                                        <i class="bi bi-x fs-2"></i>
                                                    </span>
                                                </div>
                                                <br>
                                                <small class="text-danger error-text" id="attachment_error"><?= isset($validation) ? display_error($validation, 'attachment') : '' ?></small>
                                            </div>
                                            <div class="col-lg-8 mb-3 d-flex flex-column justify-content-center">
                                                <small class="mb-3">Comp Off Leave request will be approved by HR only</small>
                                                <small>Unpaid leave has been removed, Employees who doesn't have EL/CL/CompOff balance can contact HR</small>
                                            </div>


                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">Close</button>
                                        <input type="hidden" id="create_leave_request_submit_field" name="create_leave_request_submit_field" value="Add" />
                                        <button id="create_leave_request_submit_button" class="btn btn-sm btn-primary">Add</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" tabindex="-1" id="create_od_request_modal">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content">
                                <form id="create_od_request" method="post">
                                    <div class="modal-header">
                                        <h5 class="modal-title">New OD Request <?= session()->get('current_user')['employee_id'] ?></h5>

                                        <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                                            <span class="svg-icon svg-icon-2x"></span>
                                        </div>

                                    </div>

                                    <div class="modal-body">
                                        <div class="row">

                                            <div class="col-lg-5 mb-3">
                                                <label class="form-label">Estimated From</label>
                                                <div class="input-group">
                                                    <span class="form-control p-0 border-0 flatpicker-wrapper-parent">
                                                        <input type="text" id="estimated_from_date_time" class="form-control od-control form-control-sm" name="estimated_from_date_time" placeholder="Pick a Date" value="<?= set_value('estimated_from_date_time') ?>" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
                                                    </span>
                                                    <span class="input-group-text input-group-solid cursor-pointer parent-picker">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <small class="text-danger error-text" id="estimated_from_date_time_error"><?= isset($validation) ? display_error($validation, 'estimated_from_date_time') : '' ?></small>
                                            </div>
                                            <div class="col-lg-5 mb-3">
                                                <label class="form-label">Estimated To</label>
                                                <div class="input-group">
                                                    <span class="form-control p-0 border-0 flatpicker-wrapper-parent">
                                                        <input type="text" id="estimated_to_date_time" class="form-control od-control form-control-sm" name="estimated_to_date_time" placeholder="Pick a Date" value="<?= set_value('estimated_to_date_time') ?>" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
                                                    </span>
                                                    <span class="input-group-text input-group-solid cursor-pointer parent-picker">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <small class="text-danger error-text" id="estimated_to_date_time_error"><?= isset($validation) ? display_error($validation, 'estimated_to_date_time') : '' ?></small>
                                            </div>

                                            <div class="col-lg-2 mb-3">
                                                <label class="form-label">Hours</label>
                                                <input type="text" class="form-control form-control-sm" id="hours_od" placeholder="--:--" disabled />
                                            </div>

                                            <div class="col-lg-5 mb-3">
                                                <label class="form-label">International</label>
                                                <select class="form-select form-select-sm" id="international" name="international" data-control="select2" data-placeholder="Select Yes / No" data-allow-clear="true">
                                                    <option></option>
                                                    <option value="yes" <?= edit_set_select('international', 'yes', 'no') ?>>Yes</option>
                                                    <option value="no" <?= edit_set_select('international', 'yes', 'no') ?>>No</option>
                                                </select>
                                                <small class="text-danger error-text" id="international_error"><?= isset($validation) ? display_error($validation, 'international') : '' ?></small>
                                            </div>

                                            <div class="col-lg-7 mb-3">
                                                <label class="form-label">Duty Location</label>
                                                <input type="text" id="duty_location" name="duty_location" class="form-control form-control-sm" placeholder="Duty Location" value="<?= set_value('duty_location') ?>" />
                                                <small class="text-danger error-text" id="duty_location_error"><?= isset($validation) ? display_error($validation, 'duty_location') : '' ?></small>
                                            </div>
                                            <div class="col-lg-5 mb-3">
                                                <label class="form-label">Assigned by</label>
                                                <select class="form-select form-select-sm" id="duty_assigner" name="duty_assigner" data-control="select2" data-placeholder="Assigned By" data-allow-clear="true">
                                                    <option></option>
                                                    <?php
                                                    foreach ($employees as $employee) {
                                                    ?>
                                                        <option value="<?php echo $employee['id']; ?>" <?= edit_set_select('duty_assigner', $employee['id'], $current_user_data['id']) ?>>
                                                            <?php echo ($employee['id'] == $current_user_data['id']) ? 'Self' : trim($employee['first_name'] . ' ' . $employee['last_name']) . ' (' . $employee['internal_employee_id'] . ') ' . $employee['department_name'] . '-' . $employee['company_short_name']; ?>
                                                        </option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                                <small class="text-danger error-text" id="duty_assigner_error"><?= isset($validation) ? display_error($validation, 'duty_assigner') : '' ?></small>
                                            </div>
                                            <div class="col-lg-7 mb-3">
                                                <label class="form-label">Reason</label>
                                                <input type="text" id="reason" name="reason" class="form-control form-control-sm" placeholder="Reason" value="<?= set_value('reason') ?>" />
                                                <small class="text-danger error-text" id="reason_error"><?= isset($validation) ? display_error($validation, 'reason') : '' ?></small>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">Close</button>
                                        <input type="hidden" id="create_od_request_submit_field" name="create_od_request_submit_field" value="Add" />
                                        <button id="create_od_request_submit_button" class="btn btn-sm btn-primary">Create</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" tabindex="-1" id="create_gate_pass_request_modal">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content">
                                <form id="create_gate_pass_request" method="post">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Request For Gate Pass</h5>

                                        <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                                            <span class="svg-icon svg-icon-2x"></span>
                                        </div>

                                    </div>

                                    <div class="modal-body">
                                        <div class="row">

                                            <div class="col-lg-6 mb-3">
                                                <label class="form-label mb-0">Type</label>
                                                <br><small class="text-muted mb-1">( Only Early Going option is available )</small>
                                                <div class="switch-toggle form-control form-control-sm form-control-solid d-flex p-0 position-relative">
                                                    <label for="gate_pass_type_early_going" class="text-center form-control form-control-sm bg-transparent border-0 position-relative">
                                                        Early Going <input type="radio" name="gate_pass_type" class="opacity-0 position-absolute" id="gate_pass_type_early_going" value="Early Going" checked />
                                                    </label>
                                                    <a class="bg-danger form-control form-control-sm p-0 position-absolute"></a>
                                                </div>
                                                <small class="text-danger error-text" id="gate_pass_type_error"><?= isset($validation) ? display_error($validation, 'gate_pass_type') : '' ?></small>
                                            </div>

                                            <div class="col-lg-6 mb-3">
                                                <label class="form-label mb-0">Date</label>
                                                <br><small class="text-muted mb-1">Date is fixed and can not be changed</small>
                                                <div class="input-group">
                                                    <span class="form-control p-0 border-0">
                                                        <input type="text" id="gate_pass_date" class="form-control form-control-sm" name="gate_pass_date" placeholder="Pick a Date" value="<?php echo date('Y-m-d'); ?>" style="border-top-right-radius: 0; border-bottom-right-radius: 0;" readonly>
                                                    </span>
                                                    <span class="input-group-text input-group-solid">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <small class="text-danger error-text" id="gate_pass_date_error"><?= isset($validation) ? display_error($validation, 'gate_pass_date') : '' ?></small>
                                            </div>

                                            <div class="col-lg-6 mb-3">
                                                <label class="form-label mb-0">Time (Estd)</label>
                                                <br><small class="text-muted mb-1" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; line-height: 0.85;">(Select the estimated time)</small>
                                                <div class="input-group">
                                                    <span class="form-control p-0 border-0 flatpicker-wrapper-parent">
                                                        <input type="text" id="gate_pass_hours" class="form-control form-control-sm" name="gate_pass_hours" placeholder="Estimated Time" value="<?= set_value('gate_pass_hours') ?>" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
                                                    </span>
                                                    <span class="input-group-text input-group-solid cursor-pointer parent-picker">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <small class="text-danger error-text" id="gate_pass_hours_error"><?= isset($validation) ? display_error($validation, 'gate_pass_hours') : '' ?></small>
                                            </div>

                                            <div class="col-lg-6 mb-3">
                                                <label class="form-label">Reason</label>
                                                <input type="text" id="reason" name="reason" class="form-control " placeholder="Reason" value="<?= set_value('reason') ?>" />
                                                <small class="text-danger error-text" id="reason_error"><?= isset($validation) ? display_error($validation, 'reason') : '' ?></small>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">Close</button>
                                        <button id="create_gate_pass_request_submit_button" class="btn btn-sm btn-primary">Inform Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" tabindex="-1" id="comp_off_credit_request_modal">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content">
                                <form id="comp_off_credit_request" method="post">
                                    <div class="modal-header">
                                        <h5 class="modal-title">COMP OFF Credit Request</h5>
                                        <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                                            <span class="svg-icon svg-icon-2x"></span>
                                        </div>
                                    </div>

                                    <div class="modal-body">
                                        <div class="row">

                                            <div class="col-lg-6 d-flex flex-column mb-3">
                                                <div class="mb-3">
                                                    <label class="form-label">Date</label>
                                                    <div class="input-group">
                                                        <span class="form-control p-0 border-0 flatpicker-wrapper-parent">
                                                            <input type="text" id="comp_off_credit_request_date" class="form-control cocr-control form-control-sm" name="comp_off_credit_request_date" placeholder="Pick a Date" value="<?= set_value('comp_off_credit_request_date') ?>" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
                                                        </span>
                                                        <span class="input-group-text input-group-solid cursor-pointer parent-picker">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <small class="text-danger error-text" id="comp_off_credit_request_date_error"><?= isset($validation) ? display_error($validation, 'comp_off_credit_request_date') : '' ?></small>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Assigned by</label>
                                                    <select class="form-select form-select-sm cocr-control" id="comp_off_credit_request_duty_assigner" name="comp_off_credit_request_duty_assigner" data-control="select2" data-placeholder="Assigned By" data-allow-clear="true">
                                                        <option></option>
                                                        <?php
                                                        foreach ($employees as $employee) {
                                                        ?>
                                                            <option value="<?php echo $employee['id']; ?>" <?= edit_set_select('comp_off_credit_request_duty_assigner', $employee['id'], $current_user_data['id']) ?>>
                                                                <?php echo ($employee['id'] == $current_user_data['id']) ? 'Self' : trim($employee['first_name'] . ' ' . $employee['last_name']) . ' (' . $employee['internal_employee_id'] . ') ' . $employee['department_name'] . '-' . $employee['company_short_name']; ?>
                                                            </option>
                                                        <?php
                                                        }
                                                        ?>
                                                    </select>
                                                    <small class="text-danger error-text" id="comp_off_credit_request_duty_assigner_error"><?= isset($validation) ? display_error($validation, 'comp_off_credit_request_duty_assigner') : '' ?></small>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Detailed information</label>
                                                    <input type="text" id="comp_off_credit_request_reason" name="comp_off_credit_request_reason" class="form-control form-control-sm cocr-control" placeholder="Please specify details" value="<?= set_value('comp_off_credit_request_reason') ?>" />
                                                    <small class="text-danger error-text" id="comp_off_credit_request_reason_error"><?= isset($validation) ? display_error($validation, 'comp_off_credit_request_reason') : '' ?></small>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="form-label">Attachment</label><br>
                                                    <div id="compoff_attachment_select" class="image-input image-input-outline image-input-empty" data-kt-image-input="true" style="background-image: url(<?php echo base_url(); ?>assets/media/svg/files/blank-image.svg)">
                                                        <div class="image-input-wrapper w-125px h-125px">
                                                            <a class="d-none w-100 h-100 overlay preview-button" data-bs-target="#compoff_attachment_lightbox" data-bs-toggle="modal" id="compoff_attachment_lightbox_toggle">
                                                                <div class="overlay-layer card-rounded bg-dark bg-opacity-25 shadow"><i class="bi bi-eye-fill text-white fs-3x"></i></div>
                                                            </a>
                                                        </div>
                                                        <label class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" data-bs-dismiss="click" title="Change Attachment">
                                                            <i class="bi bi-pencil-fill fs-7"></i>
                                                            <input type="file" id="compoff_attachment" name="compoff_attachment" accept=".png, .jpg, .jpeg, .pdf" />
                                                            <input type="hidden" name="compoff_attachment_remove" />
                                                        </label>
                                                        <span class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" data-bs-dismiss="click" title="Cancel Attachment">
                                                            <i class="bi bi-x fs-2"></i>
                                                        </span>
                                                        <span class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" data-bs-dismiss="click" title="Remove Attachment">
                                                            <i class="bi bi-x fs-2"></i>
                                                        </span>

                                                    </div>
                                                    <br>
                                                    <small class="text-danger error-text" id="compoff_attachment_error"><?= isset($validation) ? display_error($validation, 'compoff_attachment') : '' ?></small>
                                                </div>
                                            </div>

                                            <div class="col-lg-6 mb-3">
                                                <div id="comp_off_credit_request_working_details">

                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">Close</button>
                                        <button id="comp_off_credit_request_submit_button" class="btn btn-sm btn-primary">Request Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" tabindex="-1" id="comp_off_minutes_utilization_request_modal">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content">
                                <form id="comp_off_minutes_utilization_form" method="post">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Comp Off Utilization Request</h5>
                                        <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                                            <span class="svg-icon svg-icon-2x"></span>
                                        </div>
                                    </div>

                                    <div class="modal-body">
                                        <div class="row">

                                            <div class="col-lg-6 d-flex flex-column mb-3">
                                                <div class="mb-3">
                                                    <label class="form-label">Date</label>
                                                    <div class="input-group">
                                                        <span class="form-control p-0 border-0 flatpicker-wrapper-parent">
                                                            <input type="text" id="comp_off_minutes_utilization_date" class="form-control form-control-sm" name="comp_off_minutes_utilization_date" placeholder="Pick a Date" value="<?= set_value('comp_off_minutes_utilization_date') ?>" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
                                                        </span>
                                                        <span class="input-group-text input-group-solid cursor-pointer parent-picker">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <small class="text-danger error-text" id="comp_off_minutes_utilization_date_error"><?= isset($validation) ? display_error($validation, 'comp_off_minutes_utilization_date') : '' ?></small>
                                                </div>
                                            </div>

                                            <div class="col-lg-6 d-flex flex-column mb-3">
                                                <label class="form-label">Minutes:</label>
                                                <input class="form-control form-control-sm form-control-solid" id="comp_off_minutes_utilization_minutes" name="comp_off_minutes_utilization_minutes" data-inputmask-regex="([01]?[0-9]|2[0-3]):[0-5][0-9]" placeholder="__:__" style="width: 65px;" />
                                                <span class="text-muted d-block">Example: 00:20</span>
                                                <small class="text-danger error-text" id="comp_off_minutes_utilization_minutes_error"><?= isset($validation) ? display_error($validation, 'comp_off_minutes_utilization_minutes') : '' ?></small>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">Close</button>
                                        <button id="comp_off_minutes_utilization_submit_button" class="btn btn-sm btn-primary">Utilize Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="compoff_attachment_lightbox" data-bs-backdrop="static" aria-hidden="true" aria-labelledby="compoff_attachment_lightbox_toggle" tabindex="-1">
                        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="btn-close" data-bs-toggle="modal" href="#comp_off_credit_request_modal" role="button"></button>
                                </div>
                                <div class="modal-body" style="min-height: 70vh;">
                                    <iframe id="compoff_attachment_lightbox_iframe" class="loaded_content" width="100%" height="100%"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="leave_attachment_lightbox" data-bs-backdrop="static" aria-hidden="true" tabindex="-1">
                        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="btn-close" data-bs-toggle="modal" href="#create_leave_request_modal" role="button"></button>
                                </div>
                                <div class="modal-body" style="min-height: 70vh;">
                                    <iframe id="leave_attachment_lightbox_iframe" class="loaded_content" width="100%" height="100%"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


        <div class="shadow-sm mb-5">
            <table id="leave_balance_next_month" class="table table-sm table-row-bordered">
                <thead>
                    <tr>
                        <th style="text-align: left"><strong>Type</strong></th>
                        <th style="text-align: center"><strong>Estimated</strong></th>
                        <th style="text-align: right"><strong>Eligible</strong></th>
                    </tr>
                </thead>
            </table>
        </div>

        <?php
        if (in_array(session()->get('current_user')['role'], ['superuser', 'hr'])) {
        ?>
            <div class="shadow-sm mb-5">
                <table id="probation_ended" class="table table-sm table-striped table-row-bordered nowrap" style="font-size: 0.75rem !important">
                    <thead>
                        <tr>
                            <th style="text-align: left"><strong>Employee</strong></th>
                            <th style="text-align: center"><strong>D.O.J</strong></th>
                            <th style="text-align: center"><strong>Type</strong></th>
                            <th style="text-align: right"><strong></strong></th>
                        </tr>
                    </thead>
                </table>
            </div>
        <?php
        }
        ?>

        <?php
        if (in_array(session()->get('current_user')['role'], ['superuser', 'hr'])) {
        ?>
            <div class="shadow-sm mb-5">
                <table id="recently_joined" class="table table-sm table-striped table-row-bordered nowrap" style="font-size: 0.75rem !important">
                    <thead>
                        <tr>
                            <th style="text-align: left"><strong>Employee</strong></th>
                            <th style="text-align: center"><strong>D.O.J</strong></th>
                            <th style="text-align: right"><strong></strong></th>
                        </tr>
                    </thead>
                </table>
            </div>
        <?php
        }
        ?>

    </div>
</div>


<div class="modal fade" id="announcementPopup" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="announcementPopupLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="announcementPopupLabel" style="width: 100%; text-align: center; font-size: 22px; color: red;">Important Announcement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="width: 24px; height: 24px; text-align: center; border: none; background: transparent;">
                    <i class="fa fa-times fa-2x"></i>
                </button>
            </div>
            <div class="modal-body">

                <div class="alert alert-danger d-flex" style="font-size: 17px;">
                    <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="black"></path>
                            <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z" fill="black"></path>
                        </svg>
                    </span>
                    <div class="d-flex flex-column">
                        <h4 class="mb-1 text-danger" style="font-size: 22px;">Attendance not updating</h4>
                        <p class="mb-1">This is to inform all employees that:</p>
                        <p class="mb-1">Due to a server issue, attendance is not updating in the system.</p>
                        <p class="mb-1">We apologize for the inconvenience.</p>
                        <p class="mb-1">Please continue punching in the machine as usual to ensure your attendance reflects correctly once the issue is resolved.</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<style type="text/css">
    .modal-fullscreen .modal-content {
        height: max-content;
        border: 0;
        border-radius: 0;
        max-width: 90vw;
        max-height: 90vh;
        margin-left: auto;
        margin-right: auto;
    }
</style>


<?= $this->section('javascript') ?>

<script src="<?php echo base_url(); ?>assets/plugins/custom/datatables/datatables.bundle.js"></script>

<?php
$current_employee_id = session()->get('current_user')['employee_id'];
// if( $current_employee_id == '40' && !empty($probationPopUpEmployees) ){
if (!empty($probationPopUpEmployees)) {
?>
    <style>
        .swal2-container {
            z-index: 1100 !important;
        }

        .swal2-select {
            position: relative;
            z-index: 1200;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function() {
            const probationPopUpEmployees = JSON.parse('<?php echo json_encode($probationPopUpEmployees); ?>');
            let htmlContent = '<ul class="list-group text-start">';
            probationPopUpEmployees.forEach(employee => {
                htmlContent += `
                <li class="employee-dropdown list-group-item">
                    <div class="d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                            <div class="fw-bold">${employee.employee_name}</div>
                            <small style="font-size: 0.70rem;">is currently on ${employee.probation_status}</small>
                        </div>
                        <span class="badge bg-white border border-primary p-0">
                            <select id="employee_${employee.employee_id}" class="">
                                <option value="" disabled selected>Select an action</option>
                                <option value="Too Early to Decide">Too Early to Decide</option>
                                <option value="To be Extended">To be Extended</option>
                                <option value="Not to Confirm">Not to Confirm</option>
                                <option value="Confirmed">Confirmed</option>
                            </select>
                        </span>
                    </div>
                    <div id="error_${employee.employee_id}" style="color: red; display: none; font-size: 0.70rem;">Please select an action!</div>
              </li>
            `;
            });
            htmlContent += '</ul>';

            Swal.fire({
                title: 'Manage Employees on Probation',
                html: htmlContent,
                padding: "1rem",
                confirmButtonText: 'Save',
                showCancelButton: true,
                allowOutsideClick: false,
                preConfirm: () => {
                    let valid = true;
                    probationPopUpEmployees.forEach(employee => {
                        const selectedValue = $(`#employee_${employee.employee_id}`).val();
                        if (!selectedValue) {
                            $(`#error_${employee.employee_id}`).show();
                            valid = false;
                        } else {
                            $(`#error_${employee.employee_id}`).hide();
                        }
                    });

                    if (!valid) {
                        // Swal.showValidationMessage('Please select an action for all employees.');
                        return false;
                    }

                    const formData = {};
                    probationPopUpEmployees.forEach(employee => {
                        formData[`${employee.employee_id}`] = $(`#employee_${employee.employee_id}`).val();
                    });

                    return formData;
                },
            }).then(async (result) => {
                if (result.isConfirmed) {
                    const selectedData = {
                        'reponses': result.value
                    };
                    try {
                        const response = await $.ajax({
                            method: "POST",
                            url: "<?php echo base_url('backend/master/employee/save-probation-response-of-hod'); ?>",
                            data: selectedData,
                            success: function(response) {
                                console.log(response);
                                Swal.fire('Saved!', 'Actions have been saved successfully.', 'success');
                            },
                            error: function() {
                                Swal.fire('Error', 'Failed to save actions. Please try again.', 'error');
                            },
                        });
                    } catch (error) {
                        Swal.fire('Error', 'Failed to save actions. Please try again.', 'error');
                    }
                }
                //showAnnouncementPopup();
            });
        })
    </script>
<?php
} else {
?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            //showAnnouncementPopup();
            oneYearEmpAnniversary();
            setTimeout(function() {
                sendAbsentWithoutLeaveNotification();
            }, 10000);
        });
    </script>
<?php
}
?>

<script>
    function oneYearEmpAnniversary() {
        const currentDate = new Date();
        const oneYearAgo = new Date(currentDate);
        oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1); // Adjust year safely

        const oneYearAgoDate = oneYearAgo.toISOString().split('T')[0]; // Format YYYY-MM-DD

        $.ajax({ // Ensure jQuery is used
            url: "<?= base_url('/ajax/hr/employee/get-one-year-anniversary-employees') ?>",
            type: "POST",
            contentType: 'application/json',
            data: JSON.stringify({
                date: oneYearAgoDate
            }),
            dataType: "json",
            success: function(response) {
                if ($.trim(response.status) === 'success' && response.data) {

                    console.log('Anniversary Employees:', response.data);
                    var DOA_employees = $("#DOA_employees").DataTable({
                        "dom": '<"card"<"card-header"<"card-title"><"card-toolbar"<"datatable-buttons-container me-1"B>f<"toolbar-buttons">>><"card-body pt-1 pb-1"rt><"card-footer pt-5 pb-3"<"row"<"col-sm-12 col-md-5 d-flex align-items-center justify-content-start mb-3"><"col-sm-12 col-md-7 d-flex align-items-center justify-content-start justify-content-md-end">>>>',
                        "data": response.data,
                        "columns": [{

                                "data": function(row) {
                                    return row.first_name + ' ' + row.last_name;
                                },
                                "title": "Employee Name"
                            },
                            {
                                "data": "joining_date",
                                "title": "Date of Joining",
                                "render": function(data, type, row) {
                                    return moment(data).format('DD-MMM-YYYY');
                                }
                            },
                            {
                                "data": "anniversary_date",
                                "title": "1st Anniversary Date",
                                "render": function(data, type, row) {
                                    return moment(data).format('DD-MMM-YYYY');
                                }
                            }
                        ],
                        "order": [
                            [1, 'asc']
                        ],
                        "lengthMenu": [
                            [10, 25, 50, -1],
                            [10, 25, 50, "All"]
                        ],
                        "scrollX": true,
                        "scrollY": "300px",
                        "scrollCollapse": true,
                        "paging": false,
                        "buttons": []
                    });
                    $("#DOA_employees").closest(".card").find(".card-title").text("Completed 1 Year");
                } else {
                    console.error('Unexpected response:', response);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('Failed to fetch anniversary employees:', errorThrown,
                    'Status:', textStatus,
                    'Response:', jqXHR.responseText);
            }
        });
    }

    function sendAbsentWithoutLeaveNotification() {
        $.ajax({
            url: "<?= base_url('/ajax/hr/employee/send-absent-without-leave-notification') ?>",
            type: "POST",
            dataType: "json",
            success: function(response) {
                if ($.trim(response.response_type) === 'failed') {
                    console.log('Failed to send absent without leave notification');
                }
            }
        });


    }
    // function showAnnouncementPopup(){
    //     document.addEventListener('DOMContentLoaded', function () {
    //         var announcementPopup = new bootstrap.Modal(document.getElementById('announcementPopup'));
    //         announcementPopup.show();
    //     });
    // } 

    //function showAnnouncementPopup() {
    //   const modalElement = document.getElementById('announcementPopup');
    //  if (modalElement) {
    //      const modalInstance = new bootstrap.Modal(modalElement);
    //      modalInstance.show();
    //  } else {
    //      console.error('Modal with id "announcementPopup" not found.');
    //  }


    //}   

    function showAnnouncementPopup() {
        window.onload = function() {
            setTimeout(() => {
                const modalElement = document.getElementById('announcementPopup');
                if (modalElement) {
                    const modal = new bootstrap.Modal(modalElement);
                    modal.show();
                } else {
                    console.error('Modal with id "announcementPopup" not found.');
                }
            }, 2000); // Show modal after 2 seconds
        };
    }
</script>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        /*begin::punching_report_table*/
        var punching_report_table = $("#punching_report_table").DataTable({
            "dom": '<"card"<"card-header"<"card-title"><"card-toolbar"<"datatable-buttons-container me-1"B>f<"toolbar-buttons">>><"card-body pt-1 pb-1"rt><"card-footer pt-5 pb-3"<"row"<"col-sm-12 col-md-5 d-flex align-items-center justify-content-start mb-3"li><"col-sm-12 col-md-7 d-flex align-items-center justify-content-start justify-content-md-end"p>>>>',
            /*"buttons": [
                {
                    text: '<i class="fa-solid fa-arrow-up-right-from-square"></i> Details',
                    action: function(e, dt, node, config) {
                        // alert( 'Under construction' );
                        window.open('<?= base_url('/backend/reports/punching-report') ?>', '_blank');
                    },
                    className: 'btn btn-sm btn-light'
                },
                'colvis'
            ],*/
            "buttons": [],
            "lengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, 'All'],
            ],
            "ajax": {
                url: "<?= base_url('ajax/profile/get-punching-reports') ?>",
                error: function(jqXHR, ajaxOptions, thrownError) {
                    console.log(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                    alert(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                },
                dataSrc: "",
            },
            "deferRender": true,
            "processing": true,
            "language": {
                processing: '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="ms-3 fs-1">Processing...</span></div>',
                emptyTable: '<div class="bg-white w-100 empty-table-message d-flex align-items-center justify-content-center h-100 position-absolute" style="top:0; left:0; z-index: 1;"><span class="ms-3 fs-1">No Data Found</span></div>',
                searchPlaceholder: "Search"
            },
            "oLanguage": {
                "sSearch": ""
            },
            "columns": [{
                    data: {
                        _: 'date_time_new.formatted',
                        sort: 'date_time_new.ordering',
                    }
                },
                {
                    data: "day",
                    /*render: function(data, type, row, meta) {
                        return data.substring(0,3);
                    }*/
                },
                {
                    data: "status",
                    render: function(data, type, row, meta) {
                        /*var status_html = '<div class="d-flex flex-column">'+
                        '<strong class="cursor-pointer" data-bs-toggle="tooltip" data-bs-html="true" title="'+row.status_remarks+'">' + data + '</strong>';
                        status_html += '</div>';*/
                        var status_html = `<div class='d-flex flex-column'><strong class='cursor-pointer' data-bs-toggle='tooltip' data-bs-html='true' title='${row.status_remarks}'>${data}</strong></div>`;
                        return status_html;
                    }
                },
                {
                    render: function(data, type, row, meta) {
                        var shift_start = (row.shift_start != null) ? row.shift_start : '';
                        var shift_end = (row.shift_end != null) ? row.shift_end : '';
                        var status_html = '<div class="d-flex flex-column"><span>' + shift_start + '</span><span>' + shift_end + '</span></div>';
                        return status_html;
                    }
                },
                {
                    render: function(data, type, row, meta) {
                        var in_time_between_shift_with_od = row.in_time_between_shift_with_od !== null ? row.in_time_between_shift_with_od : '--';
                        var out_time_between_shift_with_od = row.out_time_between_shift_with_od !== null ? row.out_time_between_shift_with_od : '--';
                        var punch_in_time = row.punch_in_time !== null ? row.punch_in_time : '--';
                        var punch_out_time = row.punch_out_time !== null ? row.punch_out_time : '--';

                        var biometric_time_html = "<small class='w-100 d-flex align-items-center justify-content-between text-center text-danger' style='max-width: max-content;'>Machine: " + row.machine + "</small><div class='d-flex align-items-center justify-content-between' style='max-width: max-content; padding-top: 2px; padding-bottom: 2px;'>" +
                            "<div class='d-flex flex-column'>";
                        biometric_time_html += "<small class='text-info fs-9 px-1' style='line-height: 1.15;'>Within Shift</small>";
                        if (row.is_onOD == 'yes') {
                            biometric_time_html += "<small class='text-info fs-9 px-1' style='line-height: 1.15;'>With OD</small>";
                        }
                        biometric_time_html += "</div>";

                        biometric_time_html += "<div class='d-flex flex-column border-start border-info'>" +
                            "<small class='text-info fs-9 border-bottom border-info px-1' style='line-height: 1.15;'>" + in_time_between_shift_with_od + "</small>" +
                            "<small class='text-info fs-9 px-1' style='line-height: 1.15;'>" + out_time_between_shift_with_od + "</small>" +
                            "</div>" +
                            "</div>";

                        var punching_time_html = '<div class="cursor-pointer d-flex flex-column align-items-center" data-bs-toggle="tooltip" data-bs-html="true" title="' + biometric_time_html + '" >' +
                            '<span>' + punch_in_time + '</span>' +
                            '<span>' + punch_out_time + '</span>' +
                            '</div>';
                        return punching_time_html;
                    }
                },
                {
                    data: "late_coming_minutes",
                    render: function(data, type, row, meta) {
                        return '<strong>' + data + '</strong>';
                    }
                },
                {
                    data: "early_going_minutes",
                    render: function(data, type, row, meta) {
                        return '<strong>' + data + '</strong>';
                    }
                },
                {
                    data: "late_coming_plus_early_going_minutes",
                    render: function(data, type, row, meta) {
                        return '<strong>' + data + '</strong>';
                    }
                },
                {
                    data: "work_hours_between_shifts_including_od",
                    render: function(data, type, row, meta) {
                        return '<strong>' + data + '</strong>';
                    }
                },
                {
                    data: "paid",
                    render: function(data, type, row, meta) {
                        return '<strong>' + data + '</strong>';
                    }
                },
                {
                    data: "grace",
                    render: function(data, type, row, meta) {
                        return '<strong>' + data + '</strong>';
                    }
                }
            ],
            "order": [
                [0, 'desc']
            ],
            "scrollX": true,
            "paging": false,
            "columnDefs": [{
                    "className": 'text-center',
                    "targets": '_all'
                },
                /*{ 
                    targets: [-1,-2], 
                    visible: false 
                },*/
            ],
            "drawCallback": function(settings) {
                var response = settings.json;
            },
            "initComplete": function(settings, json) {
                const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
                const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
            },
            "headerCallback": function(thead, data, start, end, display) {
                // $(thead).find('th').eq(0).html( 'Displaying '+(end-start)+' records' );
                var api = this.api(),
                    data;
                var intVal = function(i) {
                    return typeof i === 'string' ?
                        i.replace(/[\-,]/g, '') * 1 :
                        typeof i === 'number' ?
                        i : 0;
                };

                //late_coming
                late_coming = api
                    .column(5)
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
                $(api.column(5).header()).html(
                    '<strong>Late IN<br><span class="ms-1 badge badge-danger">' + Math.round(late_coming) + '<span></strong>'
                );

                //early_going_minutes
                early_going_minutes = api
                    .column(6)
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
                $(api.column(6).header()).html(
                    '<strong>Early Out<br><span class="ms-1 badge badge-danger">' + Math.round(early_going_minutes) + '<span></strong>'
                );

                //non_working_minutes_including_od
                non_working_minutes_including_od = api
                    .column(7)
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
                $(api.column(7).header()).html(
                    '<strong>Late+Early<br><span class="ms-1 badge badge-danger">' + Math.round(non_working_minutes_including_od) + '<span></strong>'
                );

                //non_working_minutes_including_od
                paid_days = api
                    .column(9)
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
                $(api.column(9).header()).html(
                    '<strong>Paid Days<br><span class="ms-1 badge badge-success">' + paid_days + '<span></strong>'
                );

                //non_working_minutes_including_od
                grace_minutes = api
                    .column(10)
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
                $(api.column(10).header()).html(
                    '<strong>Grace<br><span class="ms-1 badge badge-success">' + Math.round(grace_minutes) + '<span></strong>'
                );
            }
        });
        $('#punching_report_table_wrapper > .card > .card-header > .card-title').replaceWith('<div class="d-flex flex-column"><h3 class="card-title">Punching Report</h3><small>As per your shift timings</small></div>');
        /*end::punching_report_table*/
        /*begin::leave_report_table*/
        var leave_report_table = $("#leave_report_table").DataTable({
            "dom": '<"card"<"card-header"<"card-title"><"card-toolbar"<"datatable-buttons-container me-1"B>f<"toolbar-buttons">>><"card-body pt-1 pb-1"rt><"card-footer pt-5 pb-3"<"row"<"col-sm-12 col-md-5 d-flex align-items-center justify-content-start mb-3"li><"col-sm-12 col-md-7 d-flex align-items-center justify-content-start justify-content-md-end"p>>>>',
            "buttons": [
                // { extend: 'excel', text: '<i class="fa-solid fa-file-excel"></i> Excel', className: 'btn btn-sm btn-light' },
                {
                    text: '<i class="fa-solid fa-arrow-up-right-from-square"></i> Details',
                    action: function(e, dt, node, config) {
                        // alert( 'Under construction' );
                        window.open('<?= base_url('/backend/user/leaves') ?>', '_blank');
                    },
                    className: 'btn btn-sm btn-light'
                }
            ],
            "lengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, 'All'],
            ],
            "ajax": {
                url: "<?= base_url('ajax/profile/get-leave-reports') ?>",
                error: function(jqXHR, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                },
                dataSrc: "",
            },
            "deferRender": true,
            "processing": true,
            "language": {
                processing: '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="ms-3 fs-1">Processing...</span></div>',
                emptyTable: '<div class="bg-white w-100 empty-table-message d-flex align-items-center justify-content-center h-100 position-absolute" style="top:0; left:0; z-index: 1;"><span class="ms-3 fs-1">No Data Found</span></div>',
                searchPlaceholder: "Search"
            },
            "oLanguage": {
                "sSearch": ""
            },
            "columns": [{
                    data: "from_date",
                    render: function(data, type, row, meta) {
                        var status_html = '<div class="d-flex flex-column">' +
                            '<span>' + data + '</span>' +
                            '<span>' + row.to_date + '</span>' +
                            '</div>';
                        return status_html;
                    }
                },
                {
                    data: "number_of_days"
                },
                {
                    data: "day_type"
                },
                {
                    data: "type_of_leave",
                    render: function(data, type, row, meta) {
                        if (row.sick_leave == 'yes') {
                            return 'SICK LEAVE';
                        }
                        return row.type_of_leave;
                    }
                },
                {
                    data: "status",
                    render: function(data, type, row, meta) {
                        var badge_class = "bg-secondary";
                        if (data == 'cancelled') {
                            /*badge_class = "bg-danger bg-opacity-15";*/
                            badge_class = "bg-dark bg-opacity-50";
                        } else if (data == 'rejected') {
                            /*badge_class = "bg-danger bg-opacity-15";*/
                            badge_class = "bg-danger";
                        } else if (data == 'approved') {
                            /*badge_class = "bg-success bg-opacity-15";*/
                            badge_class = "bg-success";
                        }
                        /*return '<span class="badge text-capitalize text-dark fw-normal rounded-pill ' + badge_class + '">' + data + '</span>';*/
                        return '<span class="badge text-capitalize rounded-pill ' + badge_class + '">' + data + '</span>';
                    }
                },
                {
                    data: "reviewed_by_name"
                },
                {
                    data: "reviewed_date"
                },
                {
                    data: "remarks",
                    render: function(data, type, row, meta) {
                        return '<p class="text-wrap" style="width: 200px">' + data + '</p>';
                    }
                },
                {
                    data: "address_d_l"
                },
                {
                    data: "emergency_contact_d_l"
                },
                {
                    data: "reason_of_leave",
                    render: function(data, type, row, meta) {
                        return '<p class="text-wrap" style="width: 200px">' + data + '</p>';
                    }
                },
                {
                    data: "attachment",
                    render: function(data, type, row, meta) {
                        if (data.length) {
                            var link = '<?php echo base_url(); ?>' + data;
                            return '<a class="badge bg-info bg-opacity-50 fw-normal rounded-pill" href="' + link + '" target="_blank">View</a>';
                        } else {
                            return '-';
                        }
                    }
                },
                {
                    data: "date_time"
                },
            ],
            "order": [],
            // "order": [[8, 'desc']],
            "scrollX": true,
            // "scrollY": 'auto',
            // "scrollY": '400px',
            "paging": false,
            "columnDefs": [
                // { "className": 'text-center fw-bold', "targets": [2] },
                {
                    "className": 'text-center',
                    "targets": '_all'
                },
            ],
        });
        $('#leave_report_table_wrapper > .card > .card-header > .card-title').replaceWith('<h3 class="card-title">Leave Report</h3>');
        /*end::leave_report_table*/
        /*begin::od_report_table*/
        var od_report_table_approved = $("#od_report_table_approved").DataTable({
            "dom": '<"card"<"card-header"<"card-title"><"card-toolbar"<"datatable-buttons-container me-1"B>f<"toolbar-buttons">>><"card-body pt-1 pb-1"rt><"card-footer pt-5 pb-3"<"row"<"col-sm-12 col-md-5 d-flex align-items-center justify-content-start mb-3"li><"col-sm-12 col-md-7 d-flex align-items-center justify-content-start justify-content-md-end"p>>>>',
            "buttons": [{
                text: '<i class="fa-solid fa-arrow-up-right-from-square"></i> Details',
                action: function(e, dt, node, config) {
                    window.open('<?= base_url('/backend/user/od') ?>', '_blank');
                },
                className: 'btn btn-sm btn-light'
            }],
            "lengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, 'All'],
            ],
            "ajax": {
                url: "<?= base_url('ajax/profile/get-od-reports-approved') ?>",
                error: function(jqXHR, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                },
                dataSrc: "",
            },
            "deferRender": true,
            "processing": true,
            "language": {
                processing: '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="ms-3 fs-1">Processing...</span></div>',
                emptyTable: '<div class="bg-white w-100 empty-table-message d-flex align-items-center justify-content-center h-100 position-absolute" style="top:0; left:0; z-index: 1;"><span class="ms-3 fs-1">No Data Found</span></div>',
                searchPlaceholder: "Search"
            },
            "oLanguage": {
                "sSearch": ""
            },
            "columns": [{
                    data: "pre_post"
                },
                {
                    data: "estimated_from_date_time"
                },
                {
                    data: "estimated_to_date_time"
                },
                {
                    data: "actual_from_date_time"
                },
                {
                    data: "actual_to_date_time"
                },
                {
                    data: "interval"
                },
                {
                    data: "duty_location"
                },
                {
                    data: "assigned_by"
                },
                {
                    data: "reason"
                },
                {
                    data: "status",
                    render: function(data, type, row, meta) {
                        var badge_class = "bg-secondary";
                        if (data == 'rejected') {
                            badge_class = "bg-danger bg-opacity-15";
                        } else if (data == 'approved') {
                            badge_class = "bg-success bg-opacity-15";
                        }
                        return '<span class="badge text-capitalize text-dark fw-normal rounded-pill ' + badge_class + '">' + data + '</span>';
                    }
                },
                {
                    data: "reviewed_by_name"
                },
                {
                    data: "reviewed_date_time"
                },
                {
                    data: "remarks"
                },
                {
                    data: "updated_date_time"
                },
                {
                    data: "date_time"
                },
            ],
            "order": [
                [8, 'desc']
            ],
            "scrollX": true,
            "paging": false,
            "columnDefs": [{
                "className": 'text-center',
                "targets": '_all'
            }, ],
            fnInitComplete: function() {
                if ($(this).find('tbody tr').length < 1) {
                    /*$(this).parent().hide();*/
                    $("#od_report_table_approved_wrapper").hide();
                }
            },
        });
        $('#od_report_table_approved_wrapper > .card > .card-header > .card-title').replaceWith('<h3 class="card-title">OD Report Approved</h3>');
        /*end::od_report_table*/
        /*begin::od_report_table*/
        var od_report_table_pending = $("#od_report_table_pending").DataTable({
            "dom": '<"card"<"card-header"<"card-title"><"card-toolbar"<"datatable-buttons-container me-1"B>f<"toolbar-buttons">>><"card-body pt-1 pb-1"rt><"card-footer pt-5 pb-3"<"row"<"col-sm-12 col-md-5 d-flex align-items-center justify-content-start mb-3"li><"col-sm-12 col-md-7 d-flex align-items-center justify-content-start justify-content-md-end"p>>>>',
            "buttons": [{
                text: '<i class="fa-solid fa-arrow-up-right-from-square"></i> Details',
                action: function(e, dt, node, config) {
                    window.open('<?= base_url('/backend/user/od') ?>', '_blank');
                },
                className: 'btn btn-sm btn-light'
            }],
            "lengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, 'All'],
            ],
            "ajax": {
                url: "<?= base_url('ajax/profile/get-od-reports-pending') ?>",
                error: function(jqXHR, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                },
                dataSrc: "",
            },
            "deferRender": true,
            "processing": true,
            "language": {
                processing: '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="ms-3 fs-1">Processing...</span></div>',
                emptyTable: '<div class="bg-white w-100 empty-table-message d-flex align-items-center justify-content-center h-100 position-absolute" style="top:0; left:0; z-index: 1;"><span class="ms-3 fs-1">No Data Found</span></div>',
                searchPlaceholder: "Search"
            },
            "oLanguage": {
                "sSearch": ""
            },
            "columns": [{
                    data: "pre_post"
                },
                {
                    data: "estimated_from_date_time"
                },
                {
                    data: "estimated_to_date_time"
                },
                {
                    data: "actual_from_date_time"
                },
                {
                    data: "actual_to_date_time"
                },
                {
                    data: "interval"
                },
                {
                    data: "duty_location"
                },
                {
                    data: "assigned_by"
                },
                {
                    data: "reason"
                },
                {
                    data: "status",
                    render: function(data, type, row, meta) {
                        var badge_class = "bg-secondary";
                        if (data == 'rejected') {
                            badge_class = "bg-danger bg-opacity-15";
                        } else if (data == 'approved') {
                            badge_class = "bg-success bg-opacity-15";
                        }
                        return '<span class="badge text-capitalize text-dark fw-normal rounded-pill ' + badge_class + '">' + data + '</span>';
                    }
                },
                {
                    data: "reviewed_by_name"
                },
                {
                    data: "reviewed_date_time"
                },
                {
                    data: "remarks"
                },
                {
                    data: "updated_date_time"
                },
                {
                    data: "date_time"
                },
            ],
            "order": [
                [8, 'desc']
            ],
            "scrollX": true,
            "paging": false,
            "columnDefs": [{
                "className": 'text-center',
                "targets": '_all'
            }, ],
            fnInitComplete: function() {
                if ($(this).find('tbody tr').length < 1) {
                    /*$(this).parent().hide();*/
                    $("#od_report_table_pending_wrapper").hide();
                }
            },
        });
        $('#od_report_table_pending_wrapper > .card > .card-header > .card-title').replaceWith('<h3 class="card-title">OD Report Pending</h3>');
        /*end::od_report_table*/


        /*begin::leave_balance_current_month*/
        var leave_balance_current_month = $("#leave_balance_current_month").DataTable({
            "dom": '<"card"<"card-header"<"card-title"><"card-toolbar"<"datatable-buttons-container me-1"B><"toolbar-buttons">>><"card-body pt-1 pb-1"rt><"card-footer">>',
            "buttons": [],
            "lengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, 'All'],
            ],
            "ajax": {
                url: "<?= base_url('ajax/profile/get-leave-balance-on-profile-page') ?>",
                error: function(jqXHR, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                },
                // dataSrc: "",
                dataSrc: function(receivedData) {
                    if (receivedData.length) {
                        $.each(receivedData, function(index, item) {
                            if (item.leave_code == 'RH') {
                                var _rh_dates = item.rh_dates;
                                if (_rh_dates.length > 0) {
                                    if (_rh_dates.length == 2) {
                                        $('#first_rh_date').val(_rh_dates[0]).trigger('change');
                                        $('#second_rh_date').val(_rh_dates[1]).trigger('change');
                                    } else {
                                        $('#first_rh_date').val(_rh_dates[0]).trigger('change');
                                        $('#second_rh_date').val('').trigger('change');
                                    }
                                }
                            }
                        })
                    }
                    $("#create_leave_request_button_trigger").html('<i class="fa fa-plus"></i> Request a Leave').removeAttr('disabled');
                    // console.log('The data has arrived', receivedData);
                    return receivedData;
                },
            },
            "deferRender": true,
            "processing": true,
            "language": {
                processing: '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="ms-3 fs-1">Processing...</span></div>',
                emptyTable: '<div class="bg-white w-100 empty-table-message d-flex align-items-center justify-content-center h-100 position-absolute" style="top:0; left:0; z-index: 1;"><span class="ms-3 fs-1">No Data Found</span></div>',
                searchPlaceholder: "Search"
            },
            "oLanguage": {
                "sSearch": ""
            },
            "columns": [{
                    data: "leave_code"
                },
                {
                    data: "balance"
                },
            ],
            "scrollX": true,
            "paging": false,
            "ordering": false,
            "columnDefs": [{
                "className": 'text-end',
                "targets": [1]
            }, ],
            // initComplete: function(json) {
            // let returned_data = json;
            // console.log(returned_data);
            // }
        });
        $('#leave_balance_current_month_wrapper > .card > .card-header > .card-title').replaceWith('<h3 class="card-title">Leave Balance</h3>');
        $('#leave_balance_current_month_wrapper > .card > .card-footer').html('<small class="d-block">If leave balance is incorrect Please contact Developer on ext 452</small>');
        /*end::leave_balance_current_month*/
        /*begin::leave_balance_next_month*/
        var leave_balance_next_month = $("#leave_balance_next_month").DataTable({
            "dom": '<"card"<"card-header"<"card-title"><"card-toolbar"<"datatable-buttons-container me-1"B><"toolbar-buttons">>><"card-body pt-1 pb-1"rt><"card-footer">>',
            "buttons": [],
            "lengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, 'All'],
            ],
            "ajax": {
                url: "<?= base_url('ajax/profile/get-leave-balance-of-next-month-on-profile-page') ?>",
                error: function(jqXHR, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                },
                dataSrc: "",
            },
            "deferRender": true,
            "processing": true,
            "language": {
                processing: '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="ms-3 fs-1">Processing...</span></div>',
                emptyTable: '<div class="bg-white w-100 empty-table-message d-flex align-items-center justify-content-center h-100 position-absolute" style="top:0; left:0; z-index: 1;"><span class="ms-3 fs-1">No Data Found</span></div>',
                searchPlaceholder: "Search"
            },
            "oLanguage": {
                "sSearch": ""
            },
            "columns": [{
                    data: "leave_code"
                },
                {
                    data: "balance"
                },
                {
                    data: "eligible_balance"
                },
            ],
            "scrollX": true,
            "paging": false,
            "ordering": false,
            "columnDefs": [{
                    "className": 'text-center',
                    "targets": [1]
                },
                {
                    "className": 'text-end',
                    "targets": [2]
                },
                {
                    "defaultContent": "-",
                    "targets": "_all"
                }
            ],
        });
        $('#leave_balance_next_month_wrapper > .card > .card-header > .card-title').replaceWith('<h3 class="card-title">Estimated/Eligible Leave Balance Next Month</h3>');
        $('#leave_balance_next_month_wrapper > .card > .card-footer').html('<small style="font-size: 0.7em;">Estimated = Current month balance + Estiamted credit of next month excluding next month requests</small><hr><small style="font-size: 0.7em;">Eligible = Estiamted credit of next month excluding next month requests (System cannot predict how many leaves are you going to apply in current month, Therefore usable balance for next month can be only the balance which will be credited next month excluding next month requests)</small>');
        /*end::leave_balance_next_month*/

        jQuery(document).on('change', '.leave_request_number_of_days', function() {
            console.log('I was here');
            var number_of_days = $(this).val();
            if ($('#day_type_half_day').is(':checked')) {
                var day_type = 0.5;
            } else {
                var day_type = 1;
            }
            var number_of_days_excluding_rh = get_interval_considering_half_day_excluding_rh('from_date', 'to_date');
            number_of_days_excluding_rh = number_of_days_excluding_rh * day_type;
            $('.included-rh-days').html('');
            var total_rh_days = number_of_days - number_of_days_excluding_rh;
            if (total_rh_days > 0) {
                $('.included-rh-days').html(total_rh_days + ' RH Day included');
            }
        });

        $('#from_date').flatpickr({
            dateFormat: 'Y-m-d',
            minDate: "<?php echo date('Y-m-01'); ?>",
            maxDate: "<?php echo date('Y-m-t'); ?>",
            altInput: false,
            static: true,
            onClose: function(selectedDates, dateStr, instance) {
                if ($('#day_type_half_day').is(':checked')) {
                    var day_type = 0.5;
                } else {
                    var day_type = 1;
                }
                var number_of_days = get_interval_considering_half_day('from_date', 'to_date');
                number_of_days = number_of_days * day_type;
                $('#number_of_days').val(number_of_days).trigger('change');



                if (day_type == 0.5 && $('#from_date').val().length && $('#to_date').val().length && number_of_days !== 0.5) {
                    Swal.fire({
                        html: 'Select same date in from date and to date',
                        icon: "error",
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        didRender: function(x) {
                            $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                            var buttons = $(".swal2-popup > .swal2-actions > button");
                            buttons.each(function(index, elem) {
                                var btnClass = $(this).attr("class");
                                var btnStyle = $(this).attr("style");
                                var btnHtml = $(this).html();
                                var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                $(this).replaceWith(newButton);
                            })
                        },
                        didClose: function(x) {
                            $('#from_date').val('').focus();
                        },
                    })
                } else if ($('#from_date').val().length && $('#to_date').val().length && number_of_days <= 0) {
                    Swal.fire({
                        html: 'Number of days can not be negative or 0',
                        icon: "error",
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        didRender: function(x) {
                            $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                            var buttons = $(".swal2-popup > .swal2-actions > button");
                            buttons.each(function(index, elem) {
                                var btnClass = $(this).attr("class");
                                var btnStyle = $(this).attr("style");
                                var btnHtml = $(this).html();
                                var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                $(this).replaceWith(newButton);
                            })
                        },
                        didClose: function(x) {
                            $('#from_date').val('').focus();
                        },
                    })
                }
            }
        })
        $('#to_date').flatpickr({
            dateFormat: 'Y-m-d',
            minDate: "<?php echo date('Y-m-01'); ?>",
            maxDate: "<?php echo date('Y-m-t'); ?>",
            altInput: false,
            static: true,
            onClose: function(selectedDates, dateStr, instance) {
                if ($('#day_type_half_day').is(':checked')) {
                    var day_type = 0.5;
                } else {
                    var day_type = 1;
                }
                var number_of_days = get_interval_considering_half_day('from_date', 'to_date');
                number_of_days = number_of_days * day_type;
                $('#number_of_days').val(number_of_days).trigger('change');


                if (day_type == 0.5 && $('#from_date').val().length && $('#to_date').val().length && number_of_days !== 0.5) {
                    Swal.fire({
                        html: 'select same date in from date and to date',
                        icon: "error",
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        didRender: function(x) {
                            $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                            var buttons = $(".swal2-popup > .swal2-actions > button");
                            buttons.each(function(index, elem) {
                                var btnClass = $(this).attr("class");
                                var btnStyle = $(this).attr("style");
                                var btnHtml = $(this).html();
                                var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                $(this).replaceWith(newButton);
                            })
                        },
                        didClose: function(x) {
                            $('#to_date').val('').focus();
                        },
                    })
                } else if ($('#from_date').val().length && $('#to_date').val().length && number_of_days <= 0) {
                    Swal.fire({
                        html: 'Number of days can not be negative or 0',
                        icon: "error",
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        didRender: function(x) {
                            $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                            var buttons = $(".swal2-popup > .swal2-actions > button");
                            buttons.each(function(index, elem) {
                                var btnClass = $(this).attr("class");
                                var btnStyle = $(this).attr("style");
                                var btnHtml = $(this).html();
                                var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                $(this).replaceWith(newButton);
                            })
                        },
                        didClose: function(x) {
                            $('#to_date').val('').focus();
                        },
                    })
                }
            }
        })
        $(document).on('change', '.type_of_leave', function(e) {
            $('#from_date').val('');
            $('#to_date').val('');
            $('#number_of_days').val('').trigger('change');
            if ($('.type_of_leave#type_of_leave_el').is(':checked') == true) {
                // $('#day_type_full_day').prop('checked', true);
                $('#day_type_half_day').parent().hide();
                $('#day_type_full_day').parent().trigger('click');
                $('#from_date').flatpickr({
                    dateFormat: 'Y-m-d',
                    // minDate: "<?php echo date('Y-m-d', strtotime('+3 days')); ?>",
                    minDate: "<?php echo date('Y-m-d', strtotime('+4 days')); ?>",
                    // maxDate: "<?php echo date('Y-12-31'); ?>",
                    // maxDate: "<?php echo date('Y-m-d', strtotime('+4 month')); ?>",
                    maxDate: "<?php echo date('Y-m-t', strtotime(date('Y-m-t') . ' +1 days')); ?>",
                    altInput: false,
                    static: true,
                    onClose: function(selectedDates, dateStr, instance) {
                        if ($('#day_type_half_day').is(':checked')) {
                            var day_type = 0.5;
                        } else {
                            var day_type = 1;
                        }
                        var number_of_days = get_interval_considering_half_day('from_date', 'to_date');
                        number_of_days = number_of_days * day_type;
                        $('#number_of_days').val(number_of_days).trigger('change');

                        if (day_type == 0.5 && $('#from_date').val().length && $('#to_date').val().length && number_of_days !== 0.5) {
                            Swal.fire({
                                html: 'Select same date in from date and to date',
                                icon: "error",
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                didRender: function(x) {
                                    $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                                    var buttons = $(".swal2-popup > .swal2-actions > button");
                                    buttons.each(function(index, elem) {
                                        var btnClass = $(this).attr("class");
                                        var btnStyle = $(this).attr("style");
                                        var btnHtml = $(this).html();
                                        var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                        $(this).replaceWith(newButton);
                                    })
                                },
                                didClose: function(x) {
                                    $('#from_date').val('').focus();
                                },
                            });
                        } else if ($('#from_date').val().length && $('#to_date').val().length && number_of_days <= 0) {
                            Swal.fire({
                                html: 'Number of days can not be negative or 0',
                                icon: "error",
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                didRender: function(x) {
                                    $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                                    var buttons = $(".swal2-popup > .swal2-actions > button");
                                    buttons.each(function(index, elem) {
                                        var btnClass = $(this).attr("class");
                                        var btnStyle = $(this).attr("style");
                                        var btnHtml = $(this).html();
                                        var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                        $(this).replaceWith(newButton);
                                    })
                                },
                                didClose: function(x) {
                                    $('#from_date').val('').focus();
                                },
                            })
                        }
                    }
                })
                $('#to_date').flatpickr({
                    dateFormat: 'Y-m-d',
                    minDate: "<?php echo date('Y-m-d', strtotime('+6 days')); ?>",
                    // maxDate: "<?php echo date('Y-12-31'); ?>",
                    // maxDate: "<?php echo date('Y-m-d', strtotime('+4 month')); ?>",
                    maxDate: "<?php echo date('Y-m-t', strtotime(date('Y-m-t') . ' +1 days')); ?>",
                    altInput: false,
                    static: true,
                    onClose: function(selectedDates, dateStr, instance) {
                        if ($('#day_type_half_day').is(':checked')) {
                            var day_type = 0.5;
                        } else {
                            var day_type = 1;
                        }
                        var number_of_days = get_interval_considering_half_day('from_date', 'to_date');
                        number_of_days = number_of_days * day_type;
                        $('#number_of_days').val(number_of_days).trigger('change');

                        if (day_type == 0.5 && $('#from_date').val().length && $('#to_date').val().length && number_of_days !== 0.5) {
                            Swal.fire({
                                html: 'select same date in from date and to date',
                                icon: "error",
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                didRender: function(x) {
                                    $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                                    var buttons = $(".swal2-popup > .swal2-actions > button");
                                    buttons.each(function(index, elem) {
                                        var btnClass = $(this).attr("class");
                                        var btnStyle = $(this).attr("style");
                                        var btnHtml = $(this).html();
                                        var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                        $(this).replaceWith(newButton);
                                    })
                                },
                                didClose: function(x) {
                                    $('#to_date').val('').focus();
                                },
                            })
                        } else if ($('#from_date').val().length && $('#to_date').val().length && number_of_days <= 0) {
                            Swal.fire({
                                html: 'Number of days can not be negative or 0',
                                icon: "error",
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                didRender: function(x) {
                                    $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                                    var buttons = $(".swal2-popup > .swal2-actions > button");
                                    buttons.each(function(index, elem) {
                                        var btnClass = $(this).attr("class");
                                        var btnStyle = $(this).attr("style");
                                        var btnHtml = $(this).html();
                                        var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                        $(this).replaceWith(newButton);
                                    })
                                },
                                didClose: function(x) {
                                    $('#to_date').val('').focus();
                                },
                            })
                        }
                    }
                })
            } else {
                $('#day_type_half_day').parent().show();
                $('#day_type_full_day').parent().trigger('click');

                $('#from_date').flatpickr({
                    dateFormat: 'Y-m-d',
                    minDate: "<?php echo date('Y-m-01'); ?>",
                    maxDate: "<?php echo date('Y-m-t'); ?>",
                    altInput: false,
                    static: true,
                    onClose: function(selectedDates, dateStr, instance) {
                        if ($('#day_type_half_day').is(':checked')) {
                            var day_type = 0.5;
                        } else {
                            var day_type = 1;
                        }
                        var number_of_days = get_interval_considering_half_day('from_date', 'to_date');
                        number_of_days = number_of_days * day_type;
                        $('#number_of_days').val(number_of_days).trigger('change');

                        if (day_type == 0.5 && $('#from_date').val().length && $('#to_date').val().length && number_of_days !== 0.5) {
                            Swal.fire({
                                html: 'Select same date in from date and to date',
                                icon: "error",
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                didRender: function(x) {
                                    $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                                    var buttons = $(".swal2-popup > .swal2-actions > button");
                                    buttons.each(function(index, elem) {
                                        var btnClass = $(this).attr("class");
                                        var btnStyle = $(this).attr("style");
                                        var btnHtml = $(this).html();
                                        var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                        $(this).replaceWith(newButton);
                                    })
                                },
                                didClose: function(x) {
                                    $('#from_date').val('').focus();
                                },
                            })
                        } else if ($('#from_date').val().length && $('#to_date').val().length && number_of_days <= 0) {
                            Swal.fire({
                                html: 'Number of days can not be negative or 0',
                                icon: "error",
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                didRender: function(x) {
                                    $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                                    var buttons = $(".swal2-popup > .swal2-actions > button");
                                    buttons.each(function(index, elem) {
                                        var btnClass = $(this).attr("class");
                                        var btnStyle = $(this).attr("style");
                                        var btnHtml = $(this).html();
                                        var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                        $(this).replaceWith(newButton);
                                    })
                                },
                                didClose: function(x) {
                                    $('#from_date').val('').focus();
                                },
                            })
                        }
                    }
                })
                $('#to_date').flatpickr({
                    dateFormat: 'Y-m-d',
                    minDate: "<?php echo date('Y-m-01'); ?>",
                    maxDate: "<?php echo date('Y-m-t'); ?>",
                    altInput: false,
                    static: true,
                    onClose: function(selectedDates, dateStr, instance) {
                        if ($('#day_type_half_day').is(':checked')) {
                            var day_type = 0.5;
                        } else {
                            var day_type = 1;
                        }
                        var number_of_days = get_interval_considering_half_day('from_date', 'to_date');
                        number_of_days = number_of_days * day_type;
                        $('#number_of_days').val(number_of_days).trigger('change');

                        if (day_type == 0.5 && $('#from_date').val().length && $('#to_date').val().length && number_of_days !== 0.5) {
                            Swal.fire({
                                html: 'select same date in from date and to date',
                                icon: "error",
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                didRender: function(x) {
                                    $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                                    var buttons = $(".swal2-popup > .swal2-actions > button");
                                    buttons.each(function(index, elem) {
                                        var btnClass = $(this).attr("class");
                                        var btnStyle = $(this).attr("style");
                                        var btnHtml = $(this).html();
                                        var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                        $(this).replaceWith(newButton);
                                    })
                                },
                                didClose: function(x) {
                                    $('#to_date').val('').focus();
                                },
                            })
                        } else if ($('#from_date').val().length && $('#to_date').val().length && number_of_days <= 0) {
                            Swal.fire({
                                html: 'Number of days can not be negative or 0',
                                icon: "error",
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                didRender: function(x) {
                                    $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                                    var buttons = $(".swal2-popup > .swal2-actions > button");
                                    buttons.each(function(index, elem) {
                                        var btnClass = $(this).attr("class");
                                        var btnStyle = $(this).attr("style");
                                        var btnHtml = $(this).html();
                                        var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                        $(this).replaceWith(newButton);
                                    })
                                },
                                didClose: function(x) {
                                    $('#to_date').val('').focus();
                                },
                            })
                        }
                    }
                })
            }
        })
        $(document).on('change', '.day_type', function(e) {
            if ($(this).is(':checked')) {
                var day_type = $(this).val();
                var number_of_days = get_interval_considering_half_day('from_date', 'to_date');
                number_of_days = number_of_days * day_type;
                $('#number_of_days').val(number_of_days).trigger('change');

                if (day_type == 0.5 && $('#from_date').val().length && $('#to_date').val().length && number_of_days !== 0.5) {
                    Swal.fire({
                        html: 'select same date in from date and to date',
                        icon: "error",
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        didRender: function(x) {
                            $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                            var buttons = $(".swal2-popup > .swal2-actions > button");
                            buttons.each(function(index, elem) {
                                var btnClass = $(this).attr("class");
                                var btnStyle = $(this).attr("style");
                                var btnHtml = $(this).html();
                                var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                $(this).replaceWith(newButton);
                            })
                        },
                        didClose: function(x) {
                            $('#to_date').val('').focus();
                        },
                    })
                } else if ($('#from_date').val().length && $('#to_date').val().length && number_of_days <= 0) {
                    Swal.fire({
                        html: 'Number of days can not be negative or 0',
                        icon: "error",
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        didRender: function(x) {
                            $(".swal2-popup.swal2-modal").removeAttr("tabindex");
                            var buttons = $(".swal2-popup > .swal2-actions > button");
                            buttons.each(function(index, elem) {
                                var btnClass = $(this).attr("class");
                                var btnStyle = $(this).attr("style");
                                var btnHtml = $(this).html();
                                var newButton = '<a class="' + btnClass + '" style="' + btnStyle + '">' + btnHtml + '</a>';
                                $(this).replaceWith(newButton);
                            })
                        },
                        didClose: function(x) {
                            $('#to_date').val('').focus();
                        },
                    })
                }
            }
        })


        $(document).on('input', '.form-control', function() {
            $(this).parent().find('.error-text').html('');
        })
        $(document).on('change', '.leave-control.flatpickr-input', function() {
            $(this).parent().parent().parent().find('.error-text').html('');
        })
        $(document).on('click', '.parent-picker', function() {
            $(this).parent().find('.flatpickr-input').focus();
        })
        $('#duty_assigner').select2({
            dropdownParent: $("#create_od_request_modal")
        });
        $('#international').select2({
            dropdownParent: $("#create_od_request_modal")
        });
        $('#estimated_from_date_time').flatpickr({
            minDate: "<?php echo date('Y-m-01'); ?>",
            /*minDate: "<?php echo date('Y-m-d', strtotime('-1 days')); ?>",*/
            maxDate: "<?php echo date('Y-m-t'); ?>",
            enableTime: true,
            altInput: false,
            static: true,
            dateFormat: "Y-m-d H:i",
            defaultDate: "<?php echo date('Y-m-d 10:00'); ?>",
            onClose: function(selectedDates, dateStr, instance) {
                check_time_interval('estimated_from_date_time', 'estimated_to_date_time', 'estimated_from_date_time', 'hours_od');
            }
        })
        $('#estimated_to_date_time').flatpickr({
            minDate: "<?php echo date('Y-m-01'); ?>",
            /*minDate: "<?php echo date('Y-m-d', strtotime('-1 days')); ?>",*/
            maxDate: "<?php echo date('Y-m-t'); ?>",
            enableTime: true,
            altInput: false,
            static: true,
            /*dateFormat: "Y-m-d H:i",
            defaultDate: "<?php #echo date('Y-m-d 18:30'); 
                            ?>",*/
            onClose: function(selectedDates, dateStr, instance) {
                check_time_interval('estimated_from_date_time', 'estimated_to_date_time', 'estimated_to_date_time', 'hours_od');
            }
        })
        /*$('#gate_pass_date').flatpickr({            
            minDate: "<?php echo date('Y-m-01'); ?>",
            maxDate: "<?php echo date('Y-m-t'); ?>",
            altInput: false,
            static: true,
        })*/
        $('#gate_pass_hours').flatpickr({
            altInput: false,
            static: true,
            noCalendar: true,
            dateFormat: "H:i",
            time_24hr: false,
            enableTime: true,
            defaultHour: '10',
            defaultMinute: '20',
        })
        $(document).on('change', '.od-control.flatpickr-input', function() {
            $(this).parent().parent().parent().find('.error-text').html('');
        })
        $(document).on('input', 'form#create_od_request .form-control', function() {
            $(this).parent().find('.error-text').html('');
        })
        $(document).on('change', 'form#create_od_request .flatpickr-input', function() {
            $(this).parent().parent().parent().parent().find('.error-text').html('');
        })
        $(document).on('click', 'form#create_od_request .parent-picker', function() {
            $(this).parent().find('.flatpickr-input').focus();
        })
        //begin::Add Leave Ajax
        $(document).on('click', '#create_leave_request_submit_button', function(e) {
            e.preventDefault();
            var currentEmployeeId = "<?php echo session()->get('current_user')['employee_id']; ?>";
            /*if( $('.type_of_leave#type_of_leave_sick_leave').is(':checked') == true && currentEmployeeId != '40' ){
                alert('this feature is under custruction');
                return false;
            }*/
            // return false;
            var form = $('#create_leave_request');
            form.closest('.modal').modal('hide');
            var data = new FormData(form[0]);
            $.ajax({
                method: "post",
                // url: "<?php echo session()->get('current_user')['employee_id'] == '40' ? base_url('ajax/create-leave-request-test') : base_url('ajax/create-leave-request'); ?>",
                url: "<?php echo base_url('ajax/create-leave-request'); ?>",
                data: data,
                processData: false,
                contentType: false,
                success: function(response) {

                    console.log(response);

                    // if( currentEmployeeId == '40' ){
                    //     return false;
                    // }

                    if (response.response_type == 'error') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "error",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                form.closest('.modal').modal('show');
                                if (typeof response.response_data.validation != 'undefined') {
                                    var validation = response.response_data.validation;
                                    $.each(validation, function(index, value) {
                                        form.find('#' + index + '_error').html(value);
                                    });
                                }
                            });
                        }
                    }

                    if (response.response_type == 'success') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "success",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                var imageInputParent = $("#attachment_select");
                                imageInputParent.removeClass('image-input-changed').addClass('image-input-empty');
                                var imageInputWrapper = $("#attachment_select .image-input-wrapper");
                                imageInputWrapper.find('.preview-button').removeClass('d-block').addClass('d-none');
                                imageInputWrapper.css({
                                    'background-image': ''
                                });
                                var previewLightboxContent = $("#previewLightboxContent");
                                previewLightboxContent.attr('src', '');
                                form[0].reset();
                                // form.closest('.modal').modal('hide');
                                $("#leave_report_table").DataTable().ajax.reload();
                                $("#leave_balance_current_month").DataTable().ajax.reload();
                                $("#leave_balance_next_month").DataTable().ajax.reload();
                            });
                        }
                    }
                },
                failed: function() {
                    Swal.fire({
                        html: "Ajax Failed, Please contact administrator",
                        icon: "error",
                        buttonsStyling: !1,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        stopKeydownPropagation: false
                    })
                }
            })
        })
        //end::Add Leave Ajax

        /*var imageInputElement = document.querySelector("#attachment_select");
        var imageInput = KTImageInput.getInstance(imageInputElement);
        imageInput.on("kt.imageinput.changed", function() {
            setTimeout(function() {
                var fileInput = $("input#attachment")[0];
                var imageInputWrapper = $("#attachment_select .image-input-wrapper");
                var previewLightboxContent = $("#previewLightboxContent");
                var reader = new FileReader();
                reader.onload = function(e) {
                    previewLightboxContent.attr('src', e.target.result);
                    imageInputWrapper.find('.preview-button').removeClass('d-none').addClass('d-block');
                    var extension = fileInput.files[0].name.split('.').pop().toLowerCase();
                    switch (extension) {
                        case 'pdf':
                            imageInputWrapper.css({
                                'background-image': 'url(<?php echo base_url(); ?>assets/media/svg/files/pdf.svg)'
                            });
                            break;
                        default:
                            break;
                    }
                }
                reader.readAsDataURL(fileInput.files[0]);
            }, 100)
        });
        imageInput.on("kt.imageinput.canceled", function() {
            setTimeout(function() {
                var imageInputWrapper = $("#attachment_select .image-input-wrapper");
                imageInputWrapper.find('.preview-button').removeClass('d-block').addClass('d-none');
                imageInputWrapper.css({
                    'background-image': ''
                });
                var previewLightboxContent = $("#previewLightboxContent");
                previewLightboxContent.attr('src', '');
            }, 100)
        });

        var imageInputElement = document.querySelector("#compoff_attachment_select");
        var imageInput = KTImageInput.getInstance(imageInputElement);
        imageInput.on("kt.imageinput.changed", function() {
            setTimeout(function() {
                var fileInput = $("input#compoff_attachment")[0];
                var imageInputWrapper = $("#compoff_attachment_select .image-input-wrapper");
                var previewLightboxContent = $("#previewLightboxContent");
                var reader = new FileReader();
                reader.onload = function(e) {
                    previewLightboxContent.attr('src', e.target.result);
                    imageInputWrapper.find('.preview-button').removeClass('d-none').addClass('d-block');
                    var extension = fileInput.files[0].name.split('.').pop().toLowerCase();
                    switch (extension) {
                        case 'pdf':
                            imageInputWrapper.css({
                                'background-image': 'url(<?php echo base_url(); ?>assets/media/svg/files/pdf.svg)'
                            });
                            break;
                        default:
                            break;
                    }
                }
                reader.readAsDataURL(fileInput.files[0]);
            }, 100)
        });
        imageInput.on("kt.imageinput.canceled", function() {
            setTimeout(function() {
                var imageInputWrapper = $("#compoff_attachment_select .image-input-wrapper");
                imageInputWrapper.find('.preview-button').removeClass('d-block').addClass('d-none');
                imageInputWrapper.css({
                    'background-image': ''
                });
                var previewLightboxContent = $("#previewLightboxContent");
                previewLightboxContent.attr('src', '');
            }, 100)
        });*/

        $('.image-input').each(function() {
            var id = $(this).attr('id');
            var imageInputElement = document.querySelector("#" + id);
            var imageInput = KTImageInput.getInstance(imageInputElement);

            var iframe_src_backup = '';

            imageInput.on("kt.imageinput.changed", function() {
                var fileInput = $("#" + id).find("input[type=file]")[0];
                var imageInputWrapper = $("#" + id + " .image-input-wrapper");
                var lightboxIframe = $($("#" + id).find(".preview-button").data("bs-target")).find("iframe");
                var reader = new FileReader();
                reader.onload = function(e) {
                    lightboxIframe.attr('src', e.target.result);
                    imageInputWrapper.find('.preview-button').removeClass('d-none').addClass('d-block');
                    var extension = fileInput.files[0].name.split('.').pop().toLowerCase();
                    switch (extension) {
                        case 'pdf':
                            imageInputWrapper.css({
                                'background-image': 'url(<?php echo base_url(); ?>assets/media/svg/files/pdf.svg)'
                            });
                            break;
                        default:
                            break;
                    }
                }
                reader.readAsDataURL(fileInput.files[0]);
            });

            imageInput.on("kt.imageinput.change", function() {
                var lightboxIframe = $($("#" + id).find(".preview-button").data("bs-target")).find("iframe");;
                if (iframe_src_backup == '') {
                    iframe_src_backup = lightboxIframe.attr('src');
                }
            });

            imageInput.on("kt.imageinput.canceled", function() {
                var lightboxIframe = $($("#" + id).find(".preview-button").data("bs-target")).find("iframe");;
                if (iframe_src_backup !== '') {
                    lightboxIframe.attr('src', iframe_src_backup);
                } else {
                    var imageInputWrapper = $("#" + id + " .image-input-wrapper");
                    imageInputWrapper.find('.preview-button').removeClass('d-block').addClass('d-none');
                    lightboxIframe.attr('src', '');
                }
            });

            imageInput.on("kt.imageinput.removed", function() {
                var imageInputWrapper = $("#" + id + " .image-input-wrapper");
                imageInputWrapper.find('.preview-button').removeClass('d-block').addClass('d-none');
                var lightboxIframe = $($("#" + id).find(".preview-button").data("bs-target")).find("iframe");;
                lightboxIframe.attr('src', '');
            });
        });


        //begin::Add OD Ajax
        $(document).on('click', '#create_od_request_submit_button', function(e) {
            e.preventDefault();
            // return false;
            var form = $('#create_od_request');
            form.closest('.modal').modal('hide');
            var data = new FormData(form[0]);
            $.ajax({
                method: "post",
                url: "<?php echo base_url('ajax/create-od-request'); ?>",
                data: data,
                processData: false,
                contentType: false,
                success: function(response) {

                    console.log(response);
                    if (response.response_type == 'error') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "error",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                if (typeof response.response_data.validation != 'undefined') {
                                    var validation = response.response_data.validation;
                                    $.each(validation, function(index, value) {
                                        form.find('#' + index + '_error').html(value);
                                        form.closest('.modal').modal('show');
                                    });
                                }
                            });
                        }
                    }

                    if (response.response_type == 'success') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "success",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                form[0].reset();
                                // form.closest('.modal').modal('hide');
                                $("#od_report_table").DataTable().ajax.reload();
                            });
                        }
                    }
                },
                failed: function() {
                    Swal.fire({
                        html: "Ajax Failed, Please contact administrator",
                        icon: "error",
                        buttonsStyling: !1,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        stopKeydownPropagation: false
                    })
                }
            })
        })
        //end::Add OD Ajax
        //begin::Add Gate Pass Ajax
        $(document).on('click', '#create_gate_pass_request_submit_button', function(e) {
            e.preventDefault();
            // return false;
            $('.error-text').html('');
            var form = $('#create_gate_pass_request');
            form.closest('.modal').modal('hide');
            var data = new FormData(form[0]);
            $.ajax({
                method: "post",
                url: "<?php echo base_url('ajax/create-gate-pass-request'); ?>",
                data: data,
                processData: false,
                contentType: false,
                success: function(response) {

                    console.log(response);


                    if (response.response_type == 'error') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "error",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                if (typeof response.response_data.validation != 'undefined') {
                                    var validation = response.response_data.validation;
                                    $.each(validation, function(index, value) {
                                        form.find('#' + index + '_error').html(value);
                                        form.closest('.modal').modal('show');
                                    });
                                }
                            });
                        }
                    }

                    if (response.response_type == 'success') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "success",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                form[0].reset();
                                // form.closest('.modal').modal('hide');
                                // $("#od_report_table").DataTable().ajax.reload();
                            });
                        }
                    }
                },
                failed: function() {
                    Swal.fire({
                        html: "Ajax Failed, Please contact administrator",
                        icon: "error",
                        buttonsStyling: !1,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        stopKeydownPropagation: false
                    })
                }
            })
        })
        //end::Add Gate Pass Ajax

        $('#comp_off_credit_request_date').flatpickr({
            enableTime: false,
            enable: <?php echo json_encode(array_column($EnabledDateForCompOffCredit, 'date')); ?>,
            minDate: "<?php echo date('Y-m-d', strtotime('-90 days')) ?>",
            maxDate: "<?php echo date('Y-m-d') ?>",
            altInput: false,
            static: true
        });
        var enabled_date_and_value = <?php echo json_encode($EnabledDateForCompOffCredit); ?>;

        $(document).on('change', '.cocr-control.flatpickr-input', function() {
            $(this).parent().parent().parent().find('.error-text').html('');
        })
        $(document).on('input', 'form#comp_off_credit_request .form-control', function() {
            $(this).parent().find('.error-text').html('');
        })
        $(document).on('change', 'form#comp_off_credit_request .flatpickr-input', function() {
            $(this).parent().parent().parent().parent().find('.error-text').html('');
        })
        $(document).on('click', 'form#comp_off_credit_request .parent-picker', function() {
            $(this).parent().find('.flatpickr-input').focus();
        })

        $('#comp_off_credit_request_duty_assigner').select2({
            dropdownParent: $("#comp_off_credit_request")
        });

        $(document).on('change', '#comp_off_credit_request_date', function(e) {
            $('#comp_off_credit_request_working_details').html(
                '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-refresh fa-spin fa-fw"></i><span class="ms-3 fs-6 text-dark">Fetching your data...</span></div>'
            );
            var comp_off_credit_request_date = $(this).val();
            $.each(enabled_date_and_value, function(enabled_date_index, enabled_date_value) {
                if (enabled_date_value.date == comp_off_credit_request_date) {
                    console.log(enabled_date_value);
                    var shift_start = (enabled_date_value.shift_start !== null) ? enabled_date_value.shift_start : '';
                    var shift_end = (enabled_date_value.shift_end !== null) ? enabled_date_value.shift_end : '';
                    var in_time__Raw = (enabled_date_value.in_time__Raw !== null) ? enabled_date_value.in_time__Raw : '';
                    var out_time__Raw = (enabled_date_value.out_time__Raw !== null) ? enabled_date_value.out_time__Raw : '';
                    var in_time_including_od = (enabled_date_value.in_time_including_od !== null) ? enabled_date_value.in_time_including_od : '';
                    var out_time_including_od = (enabled_date_value.out_time_including_od !== null) ? enabled_date_value.out_time_including_od : '';
                    $('#comp_off_credit_request_working_details').html(
                        '<ul class="list-group">' +
                        '<li class="list-group-item d-flex align-items-center justify-content-between">' +
                        '<span>Shift Start</span>' +
                        '<span>' + shift_start + '</span>' +
                        '</li>' +
                        '<li class="list-group-item d-flex align-items-center justify-content-between">' +
                        '<span>Shift End</span>' +
                        '<span>' + shift_end + '</span>' +
                        '</li>' +
                        '<li class="list-group-item d-flex align-items-center justify-content-between">' +
                        '<span>Punch In</span>' +
                        '<span>' + in_time__Raw + '</span>' +
                        '</li>' +
                        '<li class="list-group-item d-flex align-items-center justify-content-between">' +
                        '<span>Punch Out</span>' +
                        '<span>' + out_time__Raw + '</span>' +
                        '</li>' +
                        '<li class="list-group-item d-flex align-items-center justify-content-between">' +
                        '<span>Punch&OD IN</span>' +
                        '<span>' + in_time_including_od + '</span>' +
                        '</li>' +
                        '<li class="list-group-item d-flex align-items-center justify-content-between">' +
                        '<span>Punch&OD Out</span>' +
                        '<span>' + out_time_including_od + '</span>' +
                        '</li>' +
                        '</ul>'
                    );
                }
            });
            // alert(comp_off_credit_request_date);
        });
        //begin::Add COMP OFF Credit Request Ajax
        $(document).on('click', '#comp_off_credit_request_submit_button', function(e) {
            e.preventDefault();
            // return false;
            $('.error-text').html('');
            var form = $('#comp_off_credit_request');
            form.closest('.modal').modal('hide');
            var data = new FormData(form[0]);
            $.ajax({
                method: "post",
                url: "<?php echo base_url('ajax/backend/user/create-comp-off-credit-request'); ?>",
                data: data,
                processData: false,
                contentType: false,
                success: function(response) {

                    console.log(response);


                    if (response.response_type == 'error') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "error",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                if (typeof response.response_data.validation != 'undefined') {
                                    var validation = response.response_data.validation;
                                    $.each(validation, function(index, value) {
                                        form.find('#' + index + '_error').html(value);
                                        form.closest('.modal').modal('show');
                                    });
                                }
                            });
                        }
                    }

                    if (response.response_type == 'success') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "success",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                form[0].reset();
                                // form.closest('.modal').modal('hide');
                                // $("#od_report_table").DataTable().ajax.reload();
                            });
                        }
                    }
                },
                failed: function() {
                    Swal.fire({
                        html: "Ajax Failed, Please contact administrator",
                        icon: "error",
                        buttonsStyling: !1,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        stopKeydownPropagation: false
                    })
                }
            })
        })
        //end::Add COMP OFF Credit Request Ajax

        $('#comp_off_minutes_utilization_date').flatpickr({
            enableTime: false,
            minDate: "<?php echo first_date_of_last_month(); ?>",
            maxDate: "<?php echo date('Y-m-d'); ?>",
            altInput: false,
            static: true
        });

        $(document).on('click', '#comp_off_minutes_utilization_submit_button', function(e) {
            e.preventDefault();
            $('.error-text').html('');
            var form = $('#comp_off_minutes_utilization_form');
            form.closest('.modal').modal('hide');
            var data = new FormData(form[0]);
            $.ajax({
                method: "post",
                url: "<?php echo base_url('ajax/backend/user/create-comp-off-utilization-request'); ?>",
                data: data,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log(response);
                    // return false;

                    if (response.response_type == 'error') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "error",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                if (typeof response.response_data.validation != 'undefined') {
                                    var validation = response.response_data.validation;
                                    $.each(validation, function(index, value) {
                                        form.find('#' + index + '_error').html(value);
                                        form.closest('.modal').modal('show');
                                    });
                                }
                            });
                        }
                    }

                    if (response.response_type == 'success') {
                        if (response.response_description.length) {
                            Swal.fire({
                                html: response.response_description,
                                icon: "success",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                stopKeydownPropagation: false
                            }).then(function(e) {
                                form[0].reset();

                                $("#leave_report_table").DataTable().ajax.reload();
                                $("#leave_balance_current_month").DataTable().ajax.reload();
                                $("#leave_balance_next_month").DataTable().ajax.reload();
                            });
                        }
                    }
                },
                failed: function() {
                    Swal.fire({
                        html: "Ajax Failed, Please contact administrator",
                        icon: "error",
                        buttonsStyling: !1,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                        stopKeydownPropagation: false
                    })
                }
            })
        })

    })
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#create_leave_request_modal, #create_gate_pass_request_modal').on('shown.bs.modal', function() {
            /*$(this).find('#type_of_leave_ul').parent().trigger('click');*/
            $(this).find('#type_of_leave_cl').parent().trigger('click');
            var toggleSwitch = $(this).find('.switch-toggle');
            toggleSwitch.each(function(index, thisSwitch) {
                var checked_input = $(thisSwitch).find('label > input:checked').parent();
                var w = checked_input.outerWidth();
                var indexoflabel = checked_input.index();
                $(thisSwitch).find('a').css({
                    'width': w,
                    'left': indexoflabel * w
                });
            })
        })
        $(document).on('click', '.switch-toggle > label:not(.disabled)', function(e) {
            var w = $(this).outerWidth();
            $(this).find('input').prop('checked', true).trigger('change');
            if ($(this).find('input').val() == 'CL') {
                $(this).parent().find('a').removeClass('bg-danger').removeClass('bg-warning').removeClass('bg-info').addClass('bg-success');
            } else if ($(this).find('input').val() == 'EL') {
                $(this).parent().find('a').removeClass('bg-danger').removeClass('bg-success').removeClass('bg-info').addClass('bg-warning');
            } else if ($(this).find('input').val() == 'COMP OFF') {
                $(this).parent().find('a').removeClass('bg-warning').removeClass('bg-success').removeClass('bg-info').addClass('bg-danger');
            } else if ($(this).find('input').val() == 'SICK LEAVE') {
                $(this).parent().find('a').removeClass('bg-warning').removeClass('bg-success').removeClass('bg-danger').addClass('bg-info');
            } else if ($(this).find('input').val() == 'Early Going') {
                $(this).parent().find('a').removeClass('bg-warning').removeClass('bg-success').addClass('bg-danger');
            } else if ($(this).find('input').val() == 'Late Coming') {
                $(this).parent().find('a').removeClass('bg-danger').removeClass('bg-success').addClass('bg-warning');
            } else if ($(this).find('input').val() == 'Break Pass') {
                $(this).parent().find('a').removeClass('bg-danger').removeClass('bg-warning').addClass('bg-success');
            }
            $(this).parent().find('a').css({
                'width': w,
                'left': $(this).position().left
            });
        })
    })

    const get_interval_considering_half_day = (from_id, to_id) => {
        var from_date = $('#' + from_id).val();
        var to_date = $('#' + to_id).val();
        if (from_date.length && to_date.length) {
            var dt1 = new Date(from_date);
            var dt2 = new Date(to_date);
            var time_difference = dt2.getTime() - dt1.getTime();
            var result = time_difference / (1000 * 60 * 60 * 24);
            var number_of_days = result + 1;
        } else {
            var number_of_days = 0;
        }
        return number_of_days;
    }

    const get_interval_considering_half_day_excluding_rh = (from_id, to_id) => {
        var from_date = $('#' + from_id).val();
        var to_date = $('#' + to_id).val();
        if (from_date.length && to_date.length) {
            var dt1 = new Date(from_date);
            var dt2 = new Date(to_date);
            var time_difference = dt2.getTime() - dt1.getTime();
            var result = time_difference / (1000 * 60 * 60 * 24);

            //Begin::exclude RH Date
            var _first_rh_date = $("#first_rh_date").val();
            var _second_rh_date = $("#second_rh_date").val();

            if (_first_rh_date.length) {
                _first_rh_date_parsed = new Date(_first_rh_date);
                if (_first_rh_date_parsed) {
                    var _first_rh_date_timestamp = _first_rh_date_parsed.getTime();
                    var from_timestamp = dt1.getTime();
                    var to_timestamp = dt2.getTime();
                    if (_first_rh_date_timestamp >= from_timestamp && _first_rh_date_timestamp <= to_timestamp) {
                        result--;
                    }
                }
            } else if (_second_rh_date.length) {
                _second_rh_date_parsed = new Date(_second_rh_date);
                if (_second_rh_date_parsed) {
                    var _second_rh_date_timestamp = _second_rh_date_parsed.getTime();
                    var from_timestamp = dt1.getTime();
                    var to_timestamp = dt2.getTime();
                    if (_second_rh_date_timestamp >= from_timestamp && _second_rh_date_timestamp <= to_timestamp) {
                        result--;
                    }
                }
            }
            //End::exclude RH Date
            var number_of_days = result + 1;
        } else {
            var number_of_days = 0;
        }
        return number_of_days;
    }
</script>

<?php
$etime_office_error = session()->getFlashdata('etime_office_error');
if (!empty($etime_office_error)) {
?>
    <script type="text/javascript">
        $(document).ready(function() {
            Swal.fire({
                html: "<?php echo $etime_office_error; ?>",
                icon: "error",
                buttonsStyling: !1,
                confirmButtonText: "Ok, got it!",
                customClass: {
                    confirmButton: "btn btn-primary"
                },
                stopKeydownPropagation: false
            })
        })
    </script>
<?php
}
?>
<script type="text/javascript">
    jQuery(document).ready(function($) {

        /*begin::probation_ended*/
        var probation_ended = $("#probation_ended").DataTable({
            "dom": '<"card"<"card-header"<"card-title"><"card-toolbar"<"datatable-buttons-container me-1"B><"toolbar-buttons">f>><"card-body pt-1 pb-1"rt><"card-footer">>',
            "buttons": [],
            "lengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, 'All'],
            ],
            "ajax": {
                url: "<?= base_url('ajax/profile/get-probation-employees') ?>",
                error: function(jqXHR, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                },
                dataSrc: "",
            },
            "deferRender": true,
            "processing": true,
            "language": {
                processing: '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="ms-3 fs-1">Processing...</span></div>',
                emptyTable: '<div class="bg-white w-100 empty-table-message d-flex align-items-center justify-content-center h-100 position-absolute" style="top:0; left:0; z-index: 1;"><span class="ms-3 fs-1">No Data Found</span></div>',
                searchPlaceholder: "Search"
            },
            "oLanguage": {
                "sSearch": ""
            },
            "columns": [{
                    data: "employee_name"
                },
                // { data: "formatted_joining_date" },
                {
                    data: {
                        _: 'joining_date.formatted',
                        sort: 'joining_date.ordering',
                    },
                },
                {
                    data: "probation_status"
                },
                {
                    data: "employee_id",
                    render: function(data, type, row, meta) {
                        var link = "<?php echo base_url('/backend/master/employee/edit/id'); ?>/" + row.employee_id;
                        return '<a href="' + link + '" class="btn btn-icon btn-sm btn-bg-light btn-active-color-primary edit-employee p-0" style="width: max-content; height: max-content;" target="_blank"><span class="svg-icon svg-icon-3"><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true" ></i></span></a>';
                    }
                },
            ],
            "scrollX": true,
            "paging": false,
            "ordering": true,
            "columnDefs": [{
                "className": 'text-center small',
                "targets": '_all'
            }, ],
            // initComplete: function(json) {
            // let returned_data = json;
            // console.log(returned_data);
            // }
        });
        $('#probation_ended_wrapper > .card > .card-header > .card-title').replaceWith('<h3 class="card-title">Probation completed</h3>');
        // $('#probation_ended_wrapper > .card > .card-footer').html('<small class="d-block">Probation completed</small>');
        /*end::leave_balance_current_month*/

    })
</script>


<script type="text/javascript">
    jQuery(document).ready(function($) {

        /*begin::recently_joined*/
        var recently_joined = $("#recently_joined").DataTable({
            "dom": '<"card"<"card-header py-0 pe-0"<"card-title"><"card-toolbar my-0"<"datatable-buttons-container me-1"B><"toolbar-buttons">f>><"card-body pt-1 pb-1"rt><"card-footer">>',
            "buttons": [],
            "lengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, 'All'],
            ],
            "ajax": {
                url: "<?= base_url('ajax/profile/get-welcome-email-waiting') ?>",
                error: function(jqXHR, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + jqXHR.statusText + "\r\n" + jqXHR.responseText + "\r\n" + ajaxOptions.responseText);
                },
                dataSrc: "",
            },
            "deferRender": true,
            "processing": true,
            "language": {
                processing: '<div class="d-flex align-items-center justify-content-between h-100 m-auto" style="max-width:max-content"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="ms-3 fs-1">Processing...</span></div>',
                emptyTable: '<div class="bg-white w-100 empty-table-message d-flex align-items-center justify-content-center h-100 position-absolute" style="top:0; left:0; z-index: 1;"><span class="ms-3 fs-1">No Data Found</span></div>',
                searchPlaceholder: "Search"
            },
            "oLanguage": {
                "sSearch": ""
            },
            "columns": [{
                    data: "employee_name"
                },
                {
                    data: {
                        _: 'joining_date.formatted',
                        sort: 'joining_date.ordering',
                    },
                },
                {
                    data: "employee_id",
                    render: function(data, type, row, meta) {
                        return `<a href="#" data-id="${row.employee_id}" class="btn btn-icon btn-sm btn-bg-light btn-active-color-primary send-welcome-email p-0" style="width: max-content; height: max-content;" target="_blank"><span class="svg-icon svg-icon-3"><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true" ></i></span></a>`;
                    }
                },
            ],
            "scrollX": true,
            "paging": false,
            "ordering": true,
            "columnDefs": [{
                "className": 'text-center small',
                "targets": '_all'
            }, ],
            // initComplete: function(json) {
            // let returned_data = json;
            // console.log(returned_data);
            // }
        });
        $('#recently_joined_wrapper > .card > .card-header > .card-title').replaceWith('<h3 class="card-title my-0">Send welcome email</h3>');

        $(document).on('click', '.send-welcome-email', function(e) {
            e.preventDefault();
            var button = $(this);
            var button_html = button.html();

            console.log(button_html);
            console.log(button.data('id'));

            $.ajax({
                method: "post",
                url: "<?php echo base_url('/ajax/hr/employee/send-welcome-email'); ?>",
                data: {
                    'employee_id': $(this).data('id')
                },
                success: function(response) {

                    console.log(response);
                    if (response.response_type == 'failed') {
                        Swal.fire({
                            html: response.response_description,
                            icon: "error",
                            buttonsStyling: !1,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            },
                        })
                    }

                    if (response.response_type == 'success') {
                        Swal.fire({
                            html: response.response_description,
                            icon: "success",
                            buttonsStyling: !1,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            },
                        }).then(function(e) {
                            $("#recently_joined").DataTable().ajax.reload();
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        html: "Ajax Failed while sending welcome email, Please contact administrator",
                        icon: "error",
                        buttonsStyling: !1,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        },
                    })
                }
            }).always(function() {
                button.html(button_html);
            });

            $(this).html(`<span class="svg-icon svg-icon-3"><i class="fa fa-refresh fa-spin" aria-hidden="true" ></i></span>`);
        })

    })
</script>
<style type="text/css">
    #recently_joined_wrapper>.card>.card-header {
        min-height: unset;
    }
</style>

<?= $this->endSection() ?>
<?= $this->endSection() ?>
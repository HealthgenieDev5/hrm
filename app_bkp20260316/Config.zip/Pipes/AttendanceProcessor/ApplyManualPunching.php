<?php

namespace App\Pipes\AttendanceProcessor;

use App\Libraries\Pipeline;
use App\Models\EmployeeModel;
use App\Models\ManualPunchModel;
use App\Models\ShiftAttendanceRuleModel;
use App\Models\ShiftOverrideModel;
use Closure;

class ApplyManualPunching
{
    public function handle($punching_row, Closure $next)
    {
        $employee_id = $punching_row['current_user_data']['id'];
        $date = $punching_row['date'];
        $ManualPunchModel = new ManualPunchModel();
        $manualPunchData = $ManualPunchModel->where('employee_id =', $employee_id)->where('punch_date =', $date)->first();

        if (!empty($manualPunchData)) {
            $punching_row['INTime'] = $manualPunchData['punch_in'] ?? "--:--";
            $punching_row['OUTTime'] = $manualPunchData['punch_out'] ?? "--:--";
        }

        return $next($punching_row);
    }
}

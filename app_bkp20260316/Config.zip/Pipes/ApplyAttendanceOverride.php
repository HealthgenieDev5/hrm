<?php

namespace App\Pipes;

use App\AttendanceProcessor\ProcessorHelper;
use App\Models\AttendanceOverrideModel;
use Closure;

class ApplyAttendanceOverride
{
    public function handle($data, Closure $next)
    {
        $punching_data_sorted = $data['punching_data'];

        $AttendanceOverrideModel = new AttendanceOverrideModel();
        $AllAttendanceOverrides = $AttendanceOverrideModel->where('employee_id =', $data['employee_id'])->findAll();
        if (!empty($AllAttendanceOverrides) && !empty($punching_data_sorted)) {
            foreach ($AllAttendanceOverrides as $AttendanceOverride) {
                $attendance = $AttendanceOverride['attendance'];
                $attendance_date = $AttendanceOverride['attendance_date'];
                $attendance_remarks = $AttendanceOverride['remarks'];
                if ($attendance == 'P') {
                    $status = 'P';
                    $status_remarks = "Override Remarks:<br>" . $attendance_remarks;
                    $paid = '1';
                } elseif ($attendance == 'ML') {
                    $status = 'ML';
                    $status_remarks = "Override Remarks:<br>" . $attendance_remarks;
                    $paid = '1';
                } elseif ($attendance == 'H/D') {
                    $status = 'H/D';
                    $status_remarks = "Override Remarks:<br>" . $attendance_remarks;
                    $paid = '0.5';
                } elseif ($attendance == 'H/D+CL/2') {
                    $status = 'H/D+CL/2';
                    $status_remarks = "Override Remarks:<br>" . $attendance_remarks;
                    $paid = '1';
                } elseif ($attendance == 'A') {
                    $status = 'A';
                    $status_remarks = "Override Remarks:<br>" . $attendance_remarks;
                    $paid = '0';
                } else {
                    $status = '';
                    $status_remarks = '';
                    $paid = '';
                }
                foreach ($punching_data_sorted as $index => $data) {
                    if ($AttendanceOverride['attendance_date'] == $data['DateString_2']) {
                        $punching_data_sorted[$index]['status'] = !empty($status) ? $status : $data['status'];
                        $punching_data_sorted[$index]['status_remarks'] = !empty($status) ? $status_remarks . " <br><br> Original remarks:<br>" . $data['status_remarks'] : $data['status_remarks'];
                        $punching_data_sorted[$index]['paid'] = !empty($status) ? $paid : $data['paid'];
                        //added by sunny 2025-03-29 becouse of when override attendance mark as absent grace should be 0
                        $punching_data_sorted[$index]['late_coming_minutes'] = 0;
                        $punching_data_sorted[$index]['early_going_minutes'] = 0;
                        $punching_data_sorted[$index]['late_coming_plus_early_going_minutes'] = 0;

                        $punching_data_sorted[$index]['is_attendance_overridden'] = true;
                        if ($punching_data_sorted[$index]['status'] == 'A' || $punching_data_sorted[$index]['status'] == 'ML') {
                            $punching_data_sorted[$index]['grace'] = 0;
                        }

                        //end code added by sunny 2025-03-29
                    }
                }
            }
        }
        $data['punching_data'] = $punching_data_sorted;
        return $next($data);
    }
}
